DIGITÁLNY DETOX – TEST DIGITÁLNEJ ZÁŤAŽE
Verzia 0.3.0 – automatický postup, výsledková stránka a import forms.app

INŠTALÁCIA / AKTUALIZÁCIA
1. Vo WordPresse otvorte Pluginy > Pridať nový plugin > Nahrať plugin.
2. Nahrajte ZIP digitalnydetox-test-v0.3.0.zip.
3. Ak WordPress oznámi, že plugin už existuje, použite možnosť nahradiť aktuálnu verziu.
4. Na testovacej stránke /test-novy/ použite shortcode: [digitalny_detox_test]
5. Po aktualizácii sa databázová tabuľka automaticky doplní o polia pre zdroj a identifikátor importovaného záznamu.

FUNKCIE
- 13 otázok, vždy jedna otázka na obrazovke.
- Automatický prechod na ďalšiu otázku po výbere odpovede; stále je dostupné aj tlačidlo Pokračovať.
- Výraznejší kontrast pri prejdení kurzorom a jasnejšie označenie vybratej odpovede.
- Bodovanie podľa pôvodného testu, maximálne 32 bodov.
- Výsledková stránka so skóre, kategóriou, úvodným textom, bodmi a CTA podľa pôvodného PHP snippetu.
- Priebežné ukladanie odpovedí, e-mailu a súhlasu.
- Prehľad začatých, dokončených a neaktívnych relácií, detail odpovedí a CSV export.
- Import historických výsledkov z CSV exportu forms.app.
- Duplicitné Submission ID sa pri opakovanom importe preskočia.
- Historické skóre sa zachováva; ak v exporte chýba, záznam ostane bez skóre a je označený ako neúplný.
- Historické záznamy sú označené zdrojom forms.app a nemiešajú sa s novými vyplneniami.

IMPORT FORMS.APP
1. V administrácii WordPress otvorte Digitálny test > Výsledky testov.
2. V sekcii Import historických výsledkov z forms.app vyberte CSV súbor. Ak máte export v ZIP archíve, najprv ho rozbaľte a vyberte CSV súbor.
3. Kliknite na Importovať CSV. Po importe sa zobrazí počet importovaných, preskočených a chybných riadkov.
4. Opätovný import toho istého súboru je bezpečný: už existujúce Submission ID sa preskočia.

DÔLEŽITÉ
- Najskôr otestujte aktualizáciu na /test-novy/ a nevypínajte ani nemažte pôvodné dáta.
- E-mail sa zbiera až na poslednom kroku. Ak návštevník opustí test skôr, jeho e-mail nebude známy.
- Neaktívna relácia sa po 30 minútach bez uloženia zobrazuje ako opustená.
- Importované skóre sa neprepočítava. Kategória sa odvodí podľa aktuálnych hraníc: 0–9 nízke, 10–20 zvýšené, 21–32 vysoké riziko.
- V dodanom exporte je 19 úplných záznamov a 3 neúplné: dva bez skóre (jeden z nich má všetkých 13 odpovedí) a jeden so skóre 13, ale s chýbajúcou odpoveďou na otázku 2. Chýbajúce údaje sa nedopĺňajú; existujúce skóre sa zachová.
- Pred ostrým nasadením skontrolujte text podmienok, URL zásad ochrany osobných údajov a právny základ spracúvania údajov.
- IP adresa sa zámerne neukladá. Automatická lehota mazania starých záznamov nie je implementovaná.

SHORTCODE
[digitalny_detox_test]

DIGITÁLNY DETOX – TEST DIGITÁLNEJ ZÁŤAŽE
Verzia 0.1.0 – prvá testovacia verzia

INŠTALÁCIA
1. Vo WordPresse otvorte Pluginy > Pridať nový plugin > Nahrať plugin.
2. Nahrajte ZIP digitalnydetox-test.zip a aktivujte ho.
3. Na testovaciu stránku /test-novy/ vložte shortcode:
   [digitalny_detox_test]
4. V administrácii sa objaví menu „Digitálny test“.

FUNKCIE V TEJTO VERZII
- 13 otázok, jedna otázka na obrazovke.
- Bodovanie podľa zadania, maximálne 32 bodov.
- Tri výsledkové kategórie a CTA odkazy.
- Priebežné ukladanie odpovedí po každej odpovedi.
- E-mail a potvrdenie podmienok pred dokončením.
- Prehľad začatých, dokončených a neaktívnych relácií.
- Detail odpovedí a CSV export.
- Základné nastavenia vzhľadu a JSON editácia otázok/výsledkov.

DÔLEŽITÉ OBMEDZENIA / PRED NASADENÍM NAŽIVO
- Toto je prvá testovacia verzia; najprv ju nasadzujte na staging/test stránku.
- E-mail sa zbiera až pred zobrazením výsledku. Ak návštevník odíde skôr, jeho e-mail nebude známy.
- Opustená relácia sa odvodzuje z poslednej aktivity staršej ako 30 minút; záznam zostáva v stave in_progress v databáze.
- Pridajte a overte URL zásad ochrany osobných údajov v nastaveniach. Text podmienok a právny základ spracúvania osobných údajov treba pred ostrým nasadením skontrolovať.
- Zatiaľ nie je implementovaná automatická lehota mazania starých záznamov ani detailný profil návštevníka s IP adresou (IP sa zámerne neukladá).
- Otázky a výsledky možno upraviť cez JSON polia v nastaveniach; editor je určený pre administrátora, ktorý vie zachovať platnú JSON syntax.

SHORTCODE
[digitalny_detox_test]

<?php
/**
 * Plugin Name: Digitálny Detox – Test digitálnej záťaže
 * Description: Vlastný interaktívny test digitálnej záťaže s bodovaním, ukladaním priebehu a administráciou.
 * Version: 0.1.0
 * Author: DigitalnyDetox.sk
 * Text Domain: digitalnydetox-test
 */

if (!defined('ABSPATH')) exit;

class DDX_Test_Plugin {
    const VERSION = '0.1.0';
    const OPTION = 'ddx_test_config';
    const NONCE_ACTION = 'ddx_test_public';
    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_shortcode('digitalny_detox_test', array($this, 'shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('wp_ajax_ddx_save_progress', array($this, 'ajax_save_progress'));
        add_action('wp_ajax_nopriv_ddx_save_progress', array($this, 'ajax_save_progress'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_ddx_export_csv', array($this, 'export_csv'));
    }

    public function table() {
        global $wpdb;
        return $wpdb->prefix . 'ddx_test_entries';
    }

    public function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$this->table()} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            email varchar(190) DEFAULT NULL,
            answers longtext NOT NULL,
            current_step int(11) NOT NULL DEFAULT 0,
            score int(11) NOT NULL DEFAULT 0,
            result_key varchar(30) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'in_progress',
            consent tinyint(1) NOT NULL DEFAULT 0,
            started_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_id (session_id),
            KEY status (status),
            KEY updated_at (updated_at)
        ) $charset;";
        dbDelta($sql);
        if (!get_option(self::OPTION)) add_option(self::OPTION, $this->default_config());
    }

    private function default_config() {
        $questions = array(
            array('text'=>'Kontrolujem si správy/aktivity na mobile hneď po zobudení?', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Telefón mám stále po ruke, mám ho aj pri posteli.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Cítim nutkanie skontrolovať si mobil aj bez toho, aby mi prišla notifikácia.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Odkladám úlohy a povinnosti na úkor času pred obrazovkou.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Nedokážem sa sústrediť pri práci/štúdiu kvôli online vyrušeniam.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Chodievam spať neskôr, pretože som dlhšie za počítačom alebo na mobile.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Mobil používam aj pri prechádzke alebo jazde autom.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0))),
            array('text'=>'Jedávam s mobilom v ruke alebo pred televízorom, či notebookom.', 'options'=>array(array('label'=>'Áno','points'=>1),array('label'=>'Nie','points'=>0))),
            array('text'=>'Keď som bez mobilu, bývam nervózny.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Pred okolím ukrývam moje aktivity na mobile.', 'options'=>array(array('label'=>'Áno','points'=>1),array('label'=>'Nie','points'=>0))),
            array('text'=>'Denne trávim na sociálnych sieťach viac času, než by som chcel.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0))),
            array('text'=>'Cítim sa zle, keď mi niečo unikne (novinky/správy).', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Myslím si, že trávim na mobile viac času, než je pre mňa zdravé.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0)))
        );
        $common = "Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:\n• ktoré oblasti vás najviac ovplyvňujú\n• ako technológie ovplyvňujú jednotlivé oblasti vášho života\n• ako je na tom vaša digitálna rovnováha\n• vaše slabé miesto\n• čo konkrétne s tým môžete urobiť";
        return array(
            'questions'=>$questions,
            'results'=>array(
                'low'=>array('min'=>0,'max'=>9,'title'=>'Nízke riziko','subtitle'=>'Máte digitálny svet prevažne pod kontrolou','body'=>"Skvelé, máte dobré digitálne návyky a váš vzťah k technológiám je celkom zdravý!\nZdá sa, že digitálne technológie máte pod kontrolou a využívate ich prevažne užitočným spôsobom. Digitálny svet vám slúži - nie naopak.\n\nSilné stránky:\n• viete sa venovať tomu, čo je pre vás dôležité\n• máte zdravé limity a rovnováhu\n• dokážete odložiť mobil bez stresu\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-nizke-riziko/'),
                'medium'=>array('min'=>10,'max'=>20,'title'=>'Zvýšené riziko','subtitle'=>'Technológie začínajú ovplyvňovať vaše zdravie, pozornosť alebo vzťahy','body'=>"⚠️ Objavujú sa u vás digitálne návyky, ktoré vám môžu škodiť - brať energiu, sústredenie aj čas. Máte oblasti, kde digitálny svet preberá kontrolu. Ide o varovný signál, ktorý stojí za to riešiť, aby sa situácia nezhoršila. Nie je to nič dramatické - no ak nič nezmeníte, môže sa to zhoršovať. Našťastie to viete ešte otočiť pomerne jednoducho.\n\nČo vám môže spôsobovať problémy:\n• príliš veľa času online bez toho, aby ste si to uvedomovali\n• slabšia koncentrácia kvôli vyrušeniam\n• spánok a energia idú dolu\n• menej prítomnosti v osobnom živote\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-stredne-riziko/'),
                'high'=>array('min'=>21,'max'=>32,'title'=>'Vysoké riziko','subtitle'=>'Váš digitálny život prerastá do offline sveta','body'=>"🚨 Váš výsledok naznačuje, že vaša úroveň digitálneho stresu a návykov je vysoká a technológie majú pravdepodobne už pomerne výrazný dopad na vašu psychiku, výkon, spánok alebo vzťahy.\nVáš vzťah k technológiám si vyžaduje zásadnejšiu zmenu.\n\nNajčastejšie sa to prejavuje ako:\n• silné nutkanie byť stále online\n• ponocovanie a vyčerpanie\n• konflikty alebo izolácia\n• únik pred stresom cez obrazovku\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-vysoke-riziko/')
            ),
            'email_label'=>'E-mail','email_description'=>'zadajte vašu e-mailovú adresu',
            'consent_label'=>'Súhlasím s podmienkami používania.',
            'terms'=>'Tento test je bezplatný a slúži výlučne na informatívne a orientačné účely. Vyplnením a odoslaním testu nevzniká návštevníkovi žiadna povinnosť úhrady ani záväzok k nákupu.\n\nNa základe výsledku testu môže byť návštevníkovi dobrovoľne ponúknutá možnosť presmerovania na webovú stránku www.digitalnydetox.sk, kde je možné zakúpiť si detailnejší alebo rozšírený výsledok testu alebo súvisiace služby. Nákup prebieha výhradne na tejto webovej stránke a riadi sa jej samostatnými obchodnými podmienkami.\n\nÚdaje uvedené v teste sú spracované v súlade s platnými právnymi predpismi o ochrane osobných údajov a výlučne za účelom vyhodnotenia testu a zobrazenia výsledku. Prevádzkovateľ testu nezodpovedá za rozhodnutia návštevníka prijaté na základe orientačného výsledku testu.\n\nPoužívaním tohto testu potvrdzujete, že ste sa s týmito podmienkami oboznámili a súhlasíte s nimi.',
            'privacy_url'=>'', 'primary_color'=>'#FEBF00','background_color'=>'#FFFFFF','font'=>'Poppins'
        );
    }

    public function config() {
        $saved = get_option(self::OPTION, array());
        return wp_parse_args($saved, $this->default_config());
    }

    public function register_assets() {
        wp_register_style('ddx-test', plugins_url('assets/test.css', __FILE__), array(), self::VERSION);
        wp_register_script('ddx-test', plugins_url('assets/test.js', __FILE__), array(), self::VERSION, true);
    }

    public function shortcode() {
        $cfg = $this->config();
        if (empty($cfg['questions']) || !is_array($cfg['questions'])) return '<p>Test momentálne nie je dostupný.</p>';
        wp_enqueue_style('ddx-test');
        wp_enqueue_script('ddx-test');
        wp_localize_script('ddx-test', 'DDXTest', array(
            'ajaxUrl'=>admin_url('admin-ajax.php'), 'nonce'=>wp_create_nonce(self::NONCE_ACTION),
            'questions'=>$cfg['questions'], 'emailLabel'=>$cfg['email_label'], 'emailDescription'=>$cfg['email_description'],
            'consentLabel'=>$cfg['consent_label'], 'terms'=>$cfg['terms'], 'privacyUrl'=>$cfg['privacy_url'],
            'primaryColor'=>$cfg['primary_color'], 'backgroundColor'=>$cfg['background_color'], 'font'=>$cfg['font'],
            'strings'=>array('next'=>'Pokračovať','back'=>'Späť','finish'=>'Vyhodnotiť test','emailTitle'=>'Kam vám môžeme poslať výsledok?','required'=>'Vyplňte, prosím, túto položku.','invalidEmail'=>'Zadajte platnú e-mailovú adresu.','consentRequired'=>'Pre pokračovanie potvrďte súhlas s podmienkami.','sending'=>'Vyhodnocujem test…','error'=>'Údaje sa nepodarilo uložiť. Skúste to znova.')
        ));
        return '<div id="ddx-test-app" class="ddx-test-app" aria-live="polite"><div class="ddx-loading">Načítavam test…</div></div>';
    }

    public function ajax_save_progress() {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        global $wpdb;
        $session = isset($_POST['session_id']) ? sanitize_text_field(wp_unslash($_POST['session_id'])) : '';
        if (!preg_match('/^[a-f0-9-]{32,36}$/i', $session)) wp_send_json_error(array('message'=>'Neplatná relácia.'), 400);
        $cfg = $this->config();
        $answers_raw = isset($_POST['answers']) ? wp_unslash($_POST['answers']) : '{}';
        $answers = json_decode($answers_raw, true);
        if (!is_array($answers)) $answers = array();
        $clean_answers = array(); $score = 0;
        foreach ($answers as $key=>$value) {
            $index = absint($key);
            if (!isset($cfg['questions'][$index])) continue;
            $points = null;
            foreach ($cfg['questions'][$index]['options'] as $option) {
                if (isset($option['label']) && (string)$option['label'] === (string)$value) { $points = intval($option['points']); break; }
            }
            if ($points !== null) { $clean_answers[$index] = sanitize_text_field($value); $score += $points; }
        }
        $step = isset($_POST['current_step']) ? min(count($cfg['questions']), max(0, absint($_POST['current_step']))) : count($clean_answers);
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        if ($email && !is_email($email)) wp_send_json_error(array('message'=>'Neplatná e-mailová adresa.'), 400);
        $consent = !empty($_POST['consent']) ? 1 : 0;
        $complete = !empty($_POST['complete']) && $email && $consent && count($clean_answers) === count($cfg['questions']);
        $result_key = $this->result_key($score, $cfg);
        $now = current_time('mysql');
        $table = $this->table();
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE session_id=%s", $session));
        $data = array('email'=>$email ?: null, 'answers'=>wp_json_encode($clean_answers), 'current_step'=>$step, 'score'=>$score, 'result_key'=>$complete ? $result_key : null, 'status'=>$complete ? 'completed' : 'in_progress', 'consent'=>$consent, 'updated_at'=>$now, 'completed_at'=>$complete ? $now : null);
        if ($existing) $wpdb->update($table, $data, array('session_id'=>$session));
        else { $data['session_id']=$session; $data['started_at']=$now; $wpdb->insert($table, $data); }
        if ($wpdb->last_error) wp_send_json_error(array('message'=>'Databázová chyba.'), 500);
        if ($complete) {
            $r = $cfg['results'][$result_key];
            wp_send_json_success(array('complete'=>true,'score'=>$score,'result_key'=>$result_key,'result'=>$r));
        }
        wp_send_json_success(array('complete'=>false,'saved'=>true));
    }

    private function result_key($score, $cfg) {
        foreach (array('low','medium','high') as $key) {
            if (isset($cfg['results'][$key]) && $score >= intval($cfg['results'][$key]['min']) && $score <= intval($cfg['results'][$key]['max'])) return $key;
        }
        return 'low';
    }

    public function admin_menu() {
        add_menu_page('Digitálny test','Digitálny test','manage_options','ddx-test',array($this,'admin_entries'),'dashicons-clipboard',56);
        add_submenu_page('ddx-test','Výsledky testov','Výsledky testov','manage_options','ddx-test',array($this,'admin_entries'));
        add_submenu_page('ddx-test','Nastavenia testu','Nastavenia testu','manage_options','ddx-test-settings',array($this,'admin_settings'));
    }

    public function register_settings() {
        register_setting('ddx_test_group', self::OPTION, array($this,'sanitize_config'));
    }

    public function sanitize_config($input) {
        $defaults = $this->default_config();
        if (!is_array($input)) return $defaults;
        $out = $defaults;
        foreach (array('email_label','email_description','consent_label','terms','privacy_url','primary_color','background_color','font') as $key) {
            if (isset($input[$key])) $out[$key] = ($key === 'privacy_url') ? esc_url_raw($input[$key]) : sanitize_textarea_field($input[$key]);
        }
        foreach (array('questions','results') as $key) {
            if (isset($input[$key]) && is_string($input[$key])) {
                $decoded = json_decode(wp_unslash($input[$key]), true);
                if (is_array($decoded)) $out[$key] = $decoded;
            } elseif (isset($input[$key]) && is_array($input[$key])) $out[$key] = $input[$key];
        }
        return $out;
    }

    public function admin_settings() {
        if (!current_user_can('manage_options')) return;
        $cfg = $this->config();
        $qjson = wp_json_encode($cfg['questions'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $rjson = wp_json_encode($cfg['results'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        echo '<div class="wrap"><h1>Nastavenia digitálneho testu</h1><p>Otázky, odpovede a bodovanie sa dajú upravovať v JSON editore. Pred úpravou odporúčame exportovať nastavenia alebo si skopírovať pôvodný obsah.</p><form method="post" action="options.php">';
        settings_fields('ddx_test_group');
        echo '<h2>Otázky a odpovede</h2><textarea name="'.esc_attr(self::OPTION).'[questions]" rows="22" style="width:100%;font-family:monospace">'.esc_textarea($qjson).'</textarea>';
        echo '<h2>Výsledkové kategórie</h2><textarea name="'.esc_attr(self::OPTION).'[results]" rows="22" style="width:100%;font-family:monospace">'.esc_textarea($rjson).'</textarea>';
        echo '<h2>Vzhľad a texty</h2><table class="form-table"><tr><th>Primárna farba</th><td><input name="'.esc_attr(self::OPTION).'[primary_color]" value="'.esc_attr($cfg['primary_color']).'" /></td></tr><tr><th>Farba pozadia</th><td><input name="'.esc_attr(self::OPTION).'[background_color]" value="'.esc_attr($cfg['background_color']).'" /></td></tr><tr><th>Font</th><td><input name="'.esc_attr(self::OPTION).'[font]" value="'.esc_attr($cfg['font']).'" /></td></tr><tr><th>Označenie e-mailu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[email_label]" value="'.esc_attr($cfg['email_label']).'" /></td></tr><tr><th>Popis e-mailu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[email_description]" value="'.esc_attr($cfg['email_description']).'" /></td></tr><tr><th>Text súhlasu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[consent_label]" value="'.esc_attr($cfg['consent_label']).'" /></td></tr><tr><th>URL zásad ochrany súkromia</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[privacy_url]" value="'.esc_attr($cfg['privacy_url']).'" /></td></tr><tr><th>Podmienky používania</th><td><textarea name="'.esc_attr(self::OPTION).'[terms]" rows="8" class="large-text">'.esc_textarea($cfg['terms']).'</textarea></td></tr></table>';
        submit_button('Uložiť nastavenia'); echo '</form><p><strong>Shortcode:</strong> <code>[digitalny_detox_test]</code></p></div>';
    }

    public function admin_entries() {
        if (!current_user_can('manage_options')) return;
        global $wpdb; $table=$this->table();
        $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY started_at DESC LIMIT 500");
        $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
        $completed=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status='completed'");
        $started=$total; $abandoned=$total-$completed;
        echo '<div class="wrap"><h1>Výsledky a štatistiky testu</h1><p><strong>Začaté relácie:</strong> '.esc_html($started).' &nbsp; <strong>Dokončené:</strong> '.esc_html($completed).' &nbsp; <strong>Nedokončené:</strong> '.esc_html($abandoned).' &nbsp; <strong>Miera dokončenia:</strong> '.esc_html($started ? round($completed/$started*100,1) : 0).'%</p>';
        echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin-post.php?action=ddx_export_csv')).'">Exportovať CSV</a></p><table class="widefat striped"><thead><tr><th>Dátum začatia</th><th>E-mail</th><th>Stav</th><th>Posledný krok</th><th>Skóre</th><th>Výsledok</th><th>Posledná aktivita</th></tr></thead><tbody>';
        if ($rows) foreach ($rows as $row) {
            $answers=json_decode($row->answers,true); if (!is_array($answers)) $answers=array();
            $status=$row->status==='completed'?'Dokončený':(strtotime($row->updated_at) < time()-1800 ? 'Opustený / neaktívny':'Rozpracovaný');
            $step = count($answers) . ' / 13';
            echo '<tr><td>'.esc_html($row->started_at).'</td><td>'.esc_html($row->email ?: '—').'</td><td>'.esc_html($status).'</td><td>'.esc_html($step).'</td><td>'.esc_html($row->status==='completed'?$row->score:'—').'</td><td>'.esc_html($row->result_key ?: '—').'</td><td>'.esc_html($row->updated_at).'</td></tr>';
            if ($answers) echo '<tr><td colspan="7"><details><summary>Zobraziť odpovede</summary><ol>'; foreach ($answers as $i=>$answer) echo '<li>'.esc_html(isset($this->config()['questions'][$i]['text'])?$this->config()['questions'][$i]['text']:'Otázka').' — <strong>'.esc_html($answer).'</strong></li>'; if ($answers) echo '</ol></details></td></tr>';
        } else echo '<tr><td colspan="7">Zatiaľ neboli zaznamenané žiadne vyplnenia.</td></tr>';
        echo '</tbody></table><p class="description">Zobrazuje sa najviac 500 posledných relácií. Neaktívna relácia sa po 30 minútach bez uloženia zobrazuje ako opustená. E-mail bude dostupný iba vtedy, ak ho návštevník pred odchodom zadal.</p></div>';
    }

    public function export_csv() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table()} ORDER BY started_at DESC", ARRAY_A);
        nocache_headers(); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=digitalny-detox-test-vysledky.csv');
        $out=fopen('php://output','w'); fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out,array('session_id','email','status','started_at','updated_at','completed_at','current_step','score','result_key','consent','answers'),';');
        foreach ($rows as $row) fputcsv($out,array($row['session_id'],$row['email'],$row['status'],$row['started_at'],$row['updated_at'],$row['completed_at'],$row['current_step'],$row['score'],$row['result_key'],$row['consent'],$row['answers']),';');
        fclose($out); exit;
    }
}
DDX_Test_Plugin::instance();

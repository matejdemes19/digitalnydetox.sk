<?php
/**
 * Plugin Name: Digitálny Detox – Test digitálnej záťaže
 * Description: Vlastný interaktívny test digitálnej záťaže s bodovaním, ukladaním priebehu a administráciou.
 * Version: 0.4.3
 * Author: digitalnydetox.sk
 * Text Domain: digitalnydetox-test
 */

if (!defined('ABSPATH')) exit;

class DDX_Test_Plugin {
    const VERSION = '0.4.3';
    const DB_VERSION = '5';
    const OPTION = 'ddx_test_config';
    const NONCE_ACTION = 'ddx_test_public';
    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_shortcode('digitalny_detox_test', array($this, 'shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('wp_ajax_ddx_save_progress', array($this, 'ajax_save_progress'));
        add_action('wp_ajax_nopriv_ddx_save_progress', array($this, 'ajax_save_progress'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_ddx_export_csv', array($this, 'export_csv'));
        add_action('admin_post_ddx_export_marketing_csv', array($this, 'export_marketing_csv'));
        add_action('admin_post_ddx_import_formsapp', array($this, 'import_formsapp'));
        add_action('admin_post_ddx_delete_entries', array($this, 'delete_entries'));
        add_action('admin_init', array($this, 'maybe_upgrade'));
        add_action('init', array($this, 'maybe_cleanup_expired_data'), 20);
        add_action('admin_post_nopriv_ddx_unsubscribe', array($this, 'unsubscribe_marketing'));
        add_action('admin_post_ddx_unsubscribe', array($this, 'unsubscribe_marketing'));
    }

    public function table() {
        global $wpdb;
        return $wpdb->prefix . 'ddx_test_entries';
    }

    public function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$this->table()} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            source varchar(30) NOT NULL DEFAULT 'plugin',
            external_id varchar(100) DEFAULT NULL,
            email varchar(190) DEFAULT NULL,
            answers longtext NOT NULL,
            current_step int(11) NOT NULL DEFAULT 0,
            score int(11) NOT NULL DEFAULT 0,
            result_key varchar(30) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'in_progress',
            consent tinyint(1) NOT NULL DEFAULT 0,
            marketing_consent tinyint(1) NOT NULL DEFAULT 0,
            marketing_consent_at datetime DEFAULT NULL,
            email_sent_at datetime DEFAULT NULL,
            started_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            completed_at datetime DEFAULT NULL,
            page_views int(11) NOT NULL DEFAULT 0,
            first_answer_at datetime DEFAULT NULL,
            last_question int(11) NOT NULL DEFAULT 0,
            device varchar(20) DEFAULT NULL,
            os varchar(40) DEFAULT NULL,
            browser varchar(40) DEFAULT NULL,
            country varchar(100) DEFAULT NULL,
            region varchar(100) DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_id (session_id),
            KEY status (status),
            KEY updated_at (updated_at),
            UNIQUE KEY external_id (external_id)
        ) $charset;";
        dbDelta($sql);
        $marketing_sql = "CREATE TABLE {$wpdb->prefix}ddx_test_marketing (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            email varchar(190) NOT NULL,
            consented_at datetime NOT NULL,
            consent_version varchar(30) NOT NULL,
            consent_text text NOT NULL,
            withdrawn_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_id (session_id),
            KEY email (email),
            KEY withdrawn_at (withdrawn_at)
        ) $charset;";
        dbDelta($marketing_sql);
        if (!get_option(self::OPTION)) add_option(self::OPTION, $this->default_config());
        $saved = get_option(self::OPTION, array());
        if (isset($saved['results']['medium']['title']) && $saved['results']['medium']['title'] === 'Zvýšené riziko') $saved['results']['medium']['title'] = 'Stredné riziko';
        if (isset($saved['results']['high']['title']) && $saved['results']['high']['title'] === 'Vysoké riziko') $saved['results']['high']['title'] = 'Zvýšené riziko';
        update_option(self::OPTION, $saved);
        update_option('ddx_test_db_version', self::DB_VERSION);
    }

    public function maybe_upgrade() {
        if (get_option('ddx_test_db_version') !== self::DB_VERSION) {
            $this->activate();
        }
    }

    private function default_config() {
        $questions = array(
            array('text'=>'Kontrolujem si správy/aktivity na mobile hneď po zobudení?', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Telefón mám stále po ruke, mám ho aj pri posteli.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Cítim nutkanie skontrolovať si mobil aj bez toho, aby mi prišla notifikácia.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Odkladám úlohy a povinnosti na úkor času pred obrazovkou.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Nedokážem sa sústrediť pri práci/štúdiu kvôli online vyrušeniam.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Chodievam spať neskôr, pretože som dlhšie za počítačom alebo na mobile.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Mobil používam aj pri prechádzke alebo jazde autom.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0))),
            array('text'=>'Jedávam s mobilom v ruke alebo pred televízorom, či notebookom.', 'options'=>array(array('label'=>'Áno','points'=>1),array('label'=>'Nie','points'=>0))),
            array('text'=>'Keď som bez mobilu, bývam nervózny.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Pred okolím ukrývam moje aktivity na mobile.', 'options'=>array(array('label'=>'Áno','points'=>1),array('label'=>'Nie','points'=>0))),
            array('text'=>'Denne trávim na sociálnych sieťach viac času, než by som chcel.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0))),
            array('text'=>'Cítim sa zle, keď mi niečo unikne (novinky/správy).', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Myslím si, že trávim na mobile viac času, než je pre mňa zdravé.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0)))
        );
        $common = "Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:\n• ktoré oblasti vás najviac ovplyvňujú\n• ako technológie ovplyvňujú jednotlivé oblasti vášho života\n• ako je na tom vaša digitálna rovnováha\n• vaše slabé miesto\n• čo konkrétne s tým môžete urobiť";
        return array(
            'questions'=>$questions,
            'results'=>array(
                'low'=>array('min'=>0,'max'=>9,'title'=>'Nízke riziko','subtitle'=>'Máte digitálny svet prevažne pod kontrolou','lead'=>'Máte digitálny svet prevažne pod kontrolou','intro'=>'Skvelé, máte dobré digitálne návyky a váš vzťah k technológiám je celkom zdravý!','points'=>array('viete sa venovať tomu, čo je pre vás dôležité','máte zdravé limity a rovnováhu','dokážete odložiť mobil bez stresu'),'detail'=>'Zdá sa, že digitálne technológie máte pod kontrolou a využívate ich prevažne užitočným spôsobom. Digitálny svet vám slúži – nie naopak.','profile_title'=>'Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:','profile_points'=>array('ktoré oblasti vás najviac ovplyvňujú','ako technológie ovplyvňujú jednotlivé oblasti vášho života','ako je na tom vaša digitálna rovnováha','vaše slabé miesto','čo konkrétne s tým môžete urobiť'),'body'=>"Skvelé, máte dobré digitálne návyky a váš vzťah k technológiám je celkom zdravý!\nZdá sa, že digitálne technológie máte pod kontrolou a využívate ich prevažne užitočným spôsobom. Digitálny svet vám slúži - nie naopak.\n\nSilné stránky:\n• viete sa venovať tomu, čo je pre vás dôležité\n• máte zdravé limity a rovnováhu\n• dokážete odložiť mobil bez stresu\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-nizke-riziko/'),
                'medium'=>array('min'=>10,'max'=>20,'title'=>'Stredné riziko','subtitle'=>'Technológie začínajú ovplyvňovať vaše zdravie, pozornosť alebo vzťahy','lead'=>'Technológie začínajú ovplyvňovať vaše zdravie, pozornosť alebo vzťahy','intro'=>'Objavujú sa u vás digitálne návyky, ktoré vám môžu škodiť – brať energiu, sústredenie aj čas. Máte oblasti, kde digitálny svet preberá kontrolu. Ide o varovný signál, ktorý stojí za to riešiť, aby sa situácia nezhoršovala. Nie je to nič dramatické – no ak nič nezmeníte, môže sa to zhoršovať. Našťastie to viete ešte otočiť pomerne jednoducho.','points'=>array('príliš veľa času online bez toho, aby ste si to uvedomovali','slabšia koncentrácia kvôli vyrušeniam','spánok a energia idú dolu','menej prítomnosti v osobnom živote'),'detail'=>'','profile_title'=>'Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:','profile_points'=>array('ktoré oblasti vás najviac ovplyvňujú','ako technológie ovplyvňujú jednotlivé oblasti vášho života','ako je na tom vaša digitálna rovnováha','vaše slabé miesto','čo konkrétne s tým môžete urobiť'),'body'=>"⚠️ Objavujú sa u vás digitálne návyky, ktoré vám môžu škodiť - brať energiu, sústredenie aj čas. Máte oblasti, kde digitálny svet preberá kontrolu. Ide o varovný signál, ktorý stojí za to riešiť, aby sa situácia nezhoršila. Nie je to nič dramatické - no ak nič nezmeníte, môže sa to zhoršovať. Našťastie to viete ešte otočiť pomerne jednoducho.\n\nČo vám môže spôsobovať problémy:\n• príliš veľa času online bez toho, aby ste si to uvedomovali\n• slabšia koncentrácia kvôli vyrušeniam\n• spánok a energia idú dolu\n• menej prítomnosti v osobnom živote\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-stredne-riziko/'),
                'high'=>array('min'=>21,'max'=>32,'title'=>'Zvýšené riziko','subtitle'=>'Váš digitálny život prerastá do offline sveta','lead'=>'Váš digitálny život prerastá do offline sveta','intro'=>'Váš výsledok naznačuje, že vaša úroveň digitálneho stresu a návykov je vysoká a technológie majú pravdepodobne už pomerne výrazný dopad na vašu psychiku, výkon, spánok alebo vzťahy.','points'=>array('silné nutkanie byť stále online','ponocovanie a vyčerpanie','konflikty alebo izolácia','únik pred stresom cez obrazovku'),'detail'=>'Váš vzťah k technológiám si vyžaduje zásadnejšiu zmenu.','profile_title'=>'Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:','profile_points'=>array('ktoré oblasti vás najviac ovplyvňujú','ako technológie ovplyvňujú jednotlivé oblasti vášho života','ako je na tom vaša digitálna rovnováha','vaše slabé miesto','čo konkrétne s tým môžete urobiť'),'body'=>"🚨 Váš výsledok naznačuje, že vaša úroveň digitálneho stresu a návykov je vysoká a technológie majú pravdepodobne už pomerne výrazný dopad na vašu psychiku, výkon, spánok alebo vzťahy.\nVáš vzťah k technológiám si vyžaduje zásadnejšiu zmenu.\n\nNajčastejšie sa to prejavuje ako:\n• silné nutkanie byť stále online\n• ponocovanie a vyčerpanie\n• konflikty alebo izolácia\n• únik pred stresom cez obrazovku\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-vysoke-riziko/')
            ),
            'email_label'=>'E-mailová adresa','email_description'=>'vas@email.sk',
            'consent_label'=>'Potvrdzujem, že som sa oboznámil/a s podmienkami používania.',
            'marketing_label'=>'Súhlasím so zasielaním newslettera a e-mailových informácií o novinkách, tipoch, produktoch a službách projektu digitalnydetox.sk. Súhlas môžem kedykoľvek odvolať.',
            'terms'=>'Test digitálnej záťaže je bezplatný online nástroj na orientačné zhodnotenie digitálnych návykov. Test sa vyhodnocuje priamo na webovej stránke digitalnydetox.sk a po jeho dokončení sa výsledok zobrazí na obrazovke. Súhrn výsledku vám zároveň zašleme na zadanú e-mailovú adresu.\n\nVýsledok testu má informatívny a orientačný charakter. Nie je zdravotnou diagnózou, odborným posúdením ani náhradou individuálnej konzultácie s kvalifikovaným odborníkom. Vychádza z odpovedí, ktoré ste uviedli, a z metodiky automatického vyhodnotenia testu.\n\nNa výsledkovej stránke vám môžeme ponúknuť možnosť zakúpenia podrobnejšieho Detailného digitálneho profilu alebo ďalších súvisiacich služieb. Ich využitie je dobrovoľné a prípadný nákup sa uskutočňuje samostatne prostredníctvom webovej stránky digitalnydetox.sk podľa príslušných obchodných podmienok.\n\nNa účely vyhodnotenia testu a doručenia výsledku spracúvame vašu e-mailovú adresu, odpovede a výsledné skóre. Súvisiace identifikovateľné záznamy testu uchovávame 12 mesiacov. Na účely zabezpečenia fungovania a analytiky testu môžeme spracúvať aj technické údaje o zariadení, operačnom systéme a prehliadači a približné lokalizačné údaje, ak sú dostupné. Podrobnosti o prevádzkovateľovi, právnych základoch, príjemcoch, právach a spracúvaní údajov nájdete v Zásadách ochrany osobných údajov.\n\nSúhlas so zasielaním newslettera je dobrovoľný, samostatný a nie je podmienkou absolvovania testu ani doručenia výsledku.\n\nPoužívaním testu beriete na vedomie tieto podmienky.',
            'privacy_url'=>'', 'primary_color'=>'#FEBF00','background_color'=>'#FFFFFF','font'=>'Poppins'
        );
    }

    public function config() {
        $saved = get_option(self::OPTION, array());
        $defaults = $this->default_config();
        $cfg = wp_parse_args($saved, $defaults);
        if (!empty($cfg['terms']) && strpos($cfg['terms'], 'Na základe výsledku testu môže byť návštevníkovi dobrovoľne ponúknutá možnosť presmerovania') !== false) {
            $cfg['terms'] = preg_replace('/Na základe výsledku testu môže byť návštevníkovi dobrovoľne ponúknutá možnosť presmerovania[^\n]*(?:\n|$)/u', 'Po dokončení testu sa výsledok zobrazí priamo na tejto stránke a jeho súhrn vám zašleme na zadanú e-mailovú adresu.' . "\n", $cfg['terms']);
            $saved['terms'] = $cfg['terms'];
            update_option(self::OPTION, $saved);
        }
        foreach (array('low','medium','high') as $key) {
            if (isset($defaults['results'][$key])) {
                $cfg['results'][$key] = wp_parse_args(isset($cfg['results'][$key]) ? $cfg['results'][$key] : array(), $defaults['results'][$key]);
            }
        }
        return $cfg;
    }

    public function register_assets() {
        wp_register_style('ddx-test', plugins_url('assets/test.css', __FILE__), array(), self::VERSION);
        wp_register_script('ddx-test', plugins_url('assets/test.js', __FILE__), array(), self::VERSION, true);
    }

    public function shortcode() {
        $cfg = $this->config();
        if (empty($cfg['questions']) || !is_array($cfg['questions'])) return '<p>Test momentálne nie je dostupný.</p>';
        wp_enqueue_style('ddx-test');
        wp_enqueue_script('ddx-test');
        $logo_id = (int) get_theme_mod('custom_logo');
        $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
        wp_localize_script('ddx-test', 'DDXTest', array(
            'ajaxUrl'=>admin_url('admin-ajax.php'), 'nonce'=>wp_create_nonce(self::NONCE_ACTION), 'logoUrl'=>$logo_url,
            'questions'=>$cfg['questions'], 'emailLabel'=>$cfg['email_label'], 'emailDescription'=>$cfg['email_description'],
            'consentLabel'=>$cfg['consent_label'], 'marketingLabel'=>$cfg['marketing_label'], 'terms'=>$cfg['terms'], 'privacyUrl'=>$cfg['privacy_url'],
            'primaryColor'=>$cfg['primary_color'], 'backgroundColor'=>$cfg['background_color'], 'font'=>$cfg['font'],
            'strings'=>array('next'=>'Pokračovať','back'=>'Späť','finish'=>'Vyhodnotiť test','emailTitle'=>'Kam vám máme poslať výsledok?','required'=>'Vyplňte, prosím, túto položku.','invalidEmail'=>'Zadajte platnú e-mailovú adresu.','consentRequired'=>'Potvrďte, prosím, oboznámenie sa s podmienkami používania.','sending'=>'Vyhodnocujem test…','error'=>'Údaje sa nepodarilo uložiť. Skúste to znova.')
        ));
        return '<div id="ddx-test-app" class="ddx-test-app" aria-live="polite"><div class="ddx-loading">Načítavam test…</div></div>';
    }

    private function client_details() {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])), 0, 500) : '';
        $device = 'desktop';
        if (preg_match('/iPad|Tablet|PlayBook|Silk/i', $ua)) $device = 'tablet';
        elseif (preg_match('/iPhone|iPod|Mobile|Windows Phone/i', $ua)) $device = 'mobile';
        elseif (stripos($ua, 'Android') !== false) $device = 'tablet';
        $os = 'Other';
        if (stripos($ua, 'Android') !== false) $os = 'Android';
        elseif (preg_match('/iPhone|iPad|iPod/i', $ua)) $os = 'iOS';
        elseif (stripos($ua, 'Windows') !== false) $os = 'Windows';
        elseif (stripos($ua, 'Mac OS') !== false || stripos($ua, 'Macintosh') !== false) $os = 'macOS';
        elseif (stripos($ua, 'Linux') !== false) $os = 'Linux';
        $browser = 'Other';
        if (stripos($ua, 'Edg/') !== false || stripos($ua, 'EdgiOS/') !== false) $browser = 'Edge';
        elseif (stripos($ua, 'FxiOS/') !== false || stripos($ua, 'Firefox/') !== false) $browser = 'Firefox';
        elseif (stripos($ua, 'CriOS/') !== false || (stripos($ua, 'Chrome/') !== false && stripos($ua, 'Edg/') === false)) $browser = 'Chrome';
        elseif (stripos($ua, 'Safari/') !== false && stripos($ua, 'Chrome/') === false) $browser = 'Safari';
        $country = isset($_SERVER['HTTP_CF_IPCOUNTRY']) ? strtoupper(sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_IPCOUNTRY']))) : '';
        if ($country === 'XX' || $country === 'T1') $country = '';
        $region = isset($_SERVER['HTTP_CF_REGION']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_REGION'])) : '';
        $city = isset($_SERVER['HTTP_CF_IPCITY']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_IPCITY'])) : '';
        return array('device'=>$device,'os'=>$os,'browser'=>$browser,'country'=>$country,'region'=>$region,'city'=>$city);
    }

    public function ajax_save_progress() {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        global $wpdb;
        $session = isset($_POST['session_id']) ? sanitize_text_field(wp_unslash($_POST['session_id'])) : '';
        if (!preg_match('/^[a-f0-9-]{32,48}$/i', $session)) wp_send_json_error(array('message'=>'Neplatná relácia.'), 400);
        $event = isset($_POST['event']) ? sanitize_key(wp_unslash($_POST['event'])) : 'progress';
        $cfg = $this->config();
        $answers_raw = isset($_POST['answers']) ? wp_unslash($_POST['answers']) : '{}';
        $answers = json_decode($answers_raw, true);
        if (!is_array($answers)) $answers = array();
        $clean_answers = array(); $score = 0;
        foreach ($answers as $key=>$value) {
            $index = absint($key);
            if (!isset($cfg['questions'][$index])) continue;
            $points = null;
            foreach ($cfg['questions'][$index]['options'] as $option) {
                if (isset($option['label']) && (string)$option['label'] === (string)$value) { $points = intval($option['points']); break; }
            }
            if ($points !== null) { $clean_answers[$index] = sanitize_text_field($value); $score += $points; }
        }
        $step = isset($_POST['current_step']) ? min(count($cfg['questions']), max(0, absint($_POST['current_step']))) : count($clean_answers);
        $last_question = isset($_POST['last_question']) ? min(count($cfg['questions']), max(0, absint($_POST['last_question']))) : count($clean_answers);
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        if ($email && !is_email($email)) wp_send_json_error(array('message'=>'Neplatná e-mailová adresa.'), 400);
        $consent = !empty($_POST['consent']) ? 1 : 0; // potvrdenie oboznámenia sa s podmienkami
        $marketing_consent = !empty($_POST['marketing_consent']) ? 1 : 0;
        $is_completion_request = ($event === 'complete' || !empty($_POST['complete']));
        if ($is_completion_request && !$email) wp_send_json_error(array('message'=>'Zadajte e-mailovú adresu, na ktorú vám môžeme poslať výsledok.'), 400);
        if ($is_completion_request && !$consent) wp_send_json_error(array('message'=>'Potvrďte, prosím, oboznámenie sa s podmienkami používania.'), 400);
        if ($is_completion_request && count($clean_answers) !== count($cfg['questions'])) wp_send_json_error(array('message'=>'Najskôr odpovedzte na všetky otázky testu.'), 400);
        $complete = $is_completion_request && $email && $consent && count($clean_answers) === count($cfg['questions']);
        $result_key = $this->result_key($score, $cfg);
        $now = current_time('mysql');
        $table = $this->table();
        $existing = $wpdb->get_row($wpdb->prepare("SELECT id, first_answer_at, page_views, status, email_sent_at FROM $table WHERE session_id=%s", $session));
        $client = $this->client_details();
        $data = array(
            'email'=>$email ?: null, 'answers'=>wp_json_encode($clean_answers), 'current_step'=>$step,
            'score'=>$score, 'result_key'=>$complete ? $result_key : null,
            'status'=>$complete ? 'completed' : (!empty($clean_answers) ? 'in_progress' : 'viewed'),
            'consent'=>$consent, 'marketing_consent'=>$complete && $marketing_consent ? 1 : 0, 'marketing_consent_at'=>$complete && $marketing_consent ? $now : null,
            'updated_at'=>$now, 'completed_at'=>$complete ? $now : null,
            'last_question'=>max($last_question, count($clean_answers)),
            'device'=>$client['device'], 'os'=>$client['os'], 'browser'=>$client['browser'],
            'country'=>$client['country'], 'region'=>$client['region'], 'city'=>$client['city']
        );
        if (!empty($clean_answers) && (!$existing || !$existing->first_answer_at)) $data['first_answer_at'] = $now;
        if ($existing) {
            if ($event === 'view') {
                $view_data = array_merge($client, array('page_views'=>intval($existing->page_views) + 1, 'updated_at'=>$now));
                $wpdb->update($table, $view_data, array('session_id'=>$session));
            } else {
                $wpdb->update($table, $data, array('session_id'=>$session));
            }
        } else {
            $data['session_id']=$session; $data['source']='plugin'; $data['started_at']=$now;
            $data['page_views']=($event === 'view') ? 1 : 0;
            if (!empty($clean_answers)) $data['first_answer_at']=$now;
            $wpdb->insert($table, $data);
        }
        if ($wpdb->last_error) wp_send_json_error(array('message'=>'Databázová chyba.'), 500);
        if ($complete) {
            $r = $cfg['results'][$result_key];
            if ($marketing_consent) {
                $marketing_table = $wpdb->prefix . 'ddx_test_marketing';
                $wpdb->query($wpdb->prepare(
                    "INSERT INTO $marketing_table (session_id,email,consented_at,consent_version,consent_text) VALUES (%s,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE email=VALUES(email), consented_at=VALUES(consented_at), consent_version=VALUES(consent_version), consent_text=VALUES(consent_text), withdrawn_at=NULL",
                    $session, $email, $now, '2026-11-22-v1', sanitize_textarea_field($cfg['marketing_label'])
                ));
            }
            $mail_sent = false;
            if (!$existing || empty($existing->email_sent_at)) {
                $mail_sent = $this->send_result_email($email, $score, $result_key, $r);
                if ($mail_sent) $wpdb->update($table, array('email_sent_at'=>$now), array('session_id'=>$session));
            } else {
                $mail_sent = true;
            }
            wp_send_json_success(array('complete'=>true,'score'=>$score,'result_key'=>$result_key,'result'=>$r,'mail_sent'=>$mail_sent));
        }
        wp_send_json_success(array('complete'=>false,'saved'=>true));
    }

    private function send_result_email($email, $score, $result_key, $result) {
        $categories = array('low'=>'Nízke riziko', 'medium'=>'Stredné riziko', 'high'=>'Zvýšené riziko');
        $tones = array('low'=>array('#477653','#edf5ee','#dcebdd'), 'medium'=>array('#936900','#fff5d9','#ffedc0'), 'high'=>array('#a33e37','#fbeceb','#f2d9d6'));
        $recommendations = array(
            'low'=>array('Pokračujte v návykoch, ktoré vám pomáhajú udržiavať rovnováhu medzi online a offline svetom.','Zachovajte si chvíle bez telefónu, napríklad počas jedla alebo pred spaním.','Priebežne si všímajte, ktoré digitálne aktivity vám prinášajú skutočnú hodnotu.'),
            'medium'=>array('Vypnite upozornenia, ktoré nie sú dôležité alebo naliehavé.','Vyhraďte si konkrétne časy na kontrolu správ a sociálnych sietí.','Skúste prvých a posledných 30 minút dňa stráviť bez telefónu.'),
            'high'=>array('Začnite jednou konkrétnou zmenou, napríklad telefónom mimo spálne počas noci.','Vytvorte si každý deň aspoň jeden plánovaný blok času bez obrazovky.','Skontrolujte aplikácie a upozornenia, ktoré vás najčastejšie vyrušujú, a obmedzte ich.')
        );
        $label = isset($categories[$result_key]) ? $categories[$result_key] : 'Výsledok testu';
        $tone = isset($tones[$result_key]) ? $tones[$result_key] : $tones['medium'];
        $tips = isset($recommendations[$result_key]) ? $recommendations[$result_key] : $recommendations['medium'];
        $intro = isset($result['intro']) ? wp_strip_all_tags($result['intro']) : 'Ďakujeme za vyplnenie testu digitálnej záťaže.';
        $score = max(0, min(32, (int) $score));
        $percent = (int) round(($score / 32) * 100);
        $logo_id = (int) get_theme_mod('custom_logo');
        $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
        $brand = $logo_url
            ? '<img src="' . esc_url($logo_url) . '" alt="digitalnydetox.sk" width="190" style="display:block;max-width:190px;width:100%;height:auto;border:0">'
            : '<span style="font-size:22px;font-weight:800;letter-spacing:-.6px;color:#202124">digitalnydetox.sk</span>';
        $tip_rows = '';
        foreach ($tips as $i => $tip) {
            $tip_rows .= '<tr><td width="34" valign="top" style="padding:13px 0;border-bottom:1px solid #eeeae0"><span style="display:inline-block;width:24px;height:24px;line-height:24px;text-align:center;border-radius:50%;background:#ffedb1;color:#6e5200;font-weight:700;font-size:12px">' . ($i + 1) . '</span></td><td style="padding:13px 0;border-bottom:1px solid #eeeae0;color:#444;font-size:14px;line-height:1.6">' . esc_html($tip) . '</td></tr>';
        }
        $profile_url = !empty($result['url']) ? esc_url($result['url']) : '';
        $profile_cta = $profile_url ? '<tr><td style="padding:24px 26px 28px"><p style="margin:0 0 16px;color:#444;font-size:14px;line-height:1.65">Ak chcete lepšie porozumieť svojim digitálnym návykom, môžete pokračovať podrobnejším vyhodnotením.</p><a href="' . $profile_url . '" style="display:inline-block;padding:14px 20px;background:#ffbf00;color:#171717;text-decoration:none;border-radius:7px;font-size:14px;font-weight:700">Zobraziť detailný digitálny profil</a></td></tr>' : '';
        $html = '<!doctype html><html lang="sk"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;padding:24px 10px;background:#f5f5f2;font-family:Arial,Helvetica,sans-serif;color:#202124"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td align="center"><table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;background:#fff;border:1px solid #e9e6dc;border-radius:14px;overflow:hidden"><tr><td style="padding:25px 28px;border-bottom:1px solid #eee">' . $brand . '</td></tr><tr><td style="padding:28px 28px 12px"><p style="margin:0 0 8px;color:#9a7800;font-size:10px;font-weight:800;letter-spacing:1.5px;text-transform:uppercase">VÝSLEDOK TESTU DIGITÁLNEJ ZÁŤAŽE</p><h1 style="margin:0;color:#202124;font-size:25px;line-height:1.25">Vaše vyhodnotenie</h1><p style="margin:12px 0 0;color:#555;font-size:14px;line-height:1.7">' . esc_html($intro) . '</p></td></tr><tr><td style="padding:16px 28px 24px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#fffdf7;border:1px solid #eee6d2;border-radius:12px"><tr><td align="center" style="padding:24px 16px 12px"><div style="width:118px;height:118px;border:8px solid ' . esc_attr($tone[2]) . ';border-radius:100%;background:' . esc_attr($tone[1]) . ';display:table"><div style="display:table-cell;vertical-align:middle;text-align:center"><div style="font-size:40px;line-height:1;font-weight:800;color:#252525">' . $score . '</div><div style="margin-top:6px;font-size:11px;color:#665f50">z 32 bodov</div></div></div></td></tr><tr><td align="center" style="padding:0 18px 18px"><span style="display:inline-block;padding:9px 18px;border-radius:7px;background:' . esc_attr($tone[1]) . ';color:' . esc_attr($tone[0]) . ';font-size:13px;font-weight:800">' . esc_html($label) . '</span></td></tr><tr><td style="padding:0 24px 22px"><div style="height:9px;background:linear-gradient(90deg,#dfece1 0%,#dfece1 28.125%,#fff0bf 28.125%,#fff0bf 62.5%,#f4d8d5 62.5%,#f4d8d5 100%);border-radius:20px;overflow:hidden"><div style="height:9px;width:' . $percent . '%;background:' . esc_attr($tone[0]) . ';border-radius:20px"></div></div><div style="padding-top:7px;color:#777;font-size:10px"><span>0</span><span style="float:right">32 bodov</span></div></td></tr></table></td></tr><tr><td style="padding:0 28px 8px"><h2 style="margin:0 0 4px;color:#242424;font-size:18px">Čo môžete vyskúšať</h2><p style="margin:0;color:#777;font-size:12px;line-height:1.5">Tri malé kroky, ktorými môžete podporiť svoju digitálnu rovnováhu.</p><table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-top:8px">' . $tip_rows . '</table></td></tr>' . $profile_cta . '<tr><td style="padding:20px 28px;background:#faf9f5;border-top:1px solid #eeeae0"><p style="margin:0 0 10px;color:#777;font-size:11px;line-height:1.6">Výsledok je orientačný a slúži na informačné účely. Nie je zdravotnou diagnózou ani náhradou odborného posúdenia.</p><p style="margin:0 0 14px;color:#777;font-size:11px;line-height:1.6">Tento e-mail vám posielame na základe vašej požiadavky pri dokončení testu. Neprihlásili ste sa tým automaticky na odber newslettera.</p><p style="margin:0;color:#202124;font-size:13px;font-weight:800">digitalnydetox.sk</p></td></tr></table></td></tr></table></body></html>';
        $headers = array('Content-Type: text/html; charset=UTF-8', 'From: digitalnydetox.sk <' . sanitize_email(get_option('admin_email')) . '>');
        return (bool) wp_mail($email, 'Váš výsledok testu digitálnej záťaže', $html, $headers);
    }

    public function maybe_cleanup_expired_data() {
        $last = (int) get_option('ddx_last_retention_cleanup', 0);
        if ($last && (time() - $last) < DAY_IN_SECONDS) return;
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->query($wpdb->prepare("DELETE FROM {$this->table()} WHERE COALESCE(completed_at, updated_at, started_at) < DATE_SUB(%s, INTERVAL 12 MONTH)", $now));
        $marketing_table = $wpdb->prefix . 'ddx_test_marketing';
        $wpdb->query($wpdb->prepare("DELETE FROM $marketing_table WHERE withdrawn_at IS NOT NULL AND withdrawn_at < DATE_SUB(%s, INTERVAL 4 YEAR)", $now));
        update_option('ddx_last_retention_cleanup', time(), false);
    }

    public function unsubscribe_marketing() {
        global $wpdb;
        $session_raw = isset($_REQUEST['sid']) ? $_REQUEST['sid'] : '';
        $token_raw = isset($_REQUEST['token']) ? $_REQUEST['token'] : '';
        $session = sanitize_text_field(wp_unslash($session_raw));
        $token = sanitize_text_field(wp_unslash($token_raw));
        $table = $wpdb->prefix . 'ddx_test_marketing';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE session_id=%s", $session));
        if (!$row || !$token) wp_die('Odkaz na odvolanie súhlasu nie je platný.');
        $expected = wp_hash($row->session_id . '|' . $row->email . '|' . $row->consented_at);
        if (!hash_equals($expected, $token)) wp_die('Odkaz na odvolanie súhlasu nie je platný.');
        if (empty($_POST['confirm'])) {
            $action = esc_url(admin_url('admin-post.php'));
            $sid_html = esc_attr($row->session_id);
            $token_html = esc_attr($token);
            wp_die('<div style="max-width:620px;margin:60px auto;font:16px/1.6 sans-serif"><h1>Odvolanie súhlasu s newsletterom</h1><p>Potvrdzujete, že už nechcete dostávať newsletter a marketingové e-maily z digitalnydetox.sk?</p><form method="post" action="' . $action . '"><input type="hidden" name="action" value="ddx_unsubscribe"><input type="hidden" name="sid" value="' . $sid_html . '"><input type="hidden" name="token" value="' . $token_html . '"><input type="hidden" name="confirm" value="1"><button type="submit" style="padding:12px 18px;cursor:pointer">Potvrdiť odvolanie súhlasu</button></form></div>', 'digitalnydetox.sk');
        }
        if (empty($row->withdrawn_at)) $wpdb->update($table, array('withdrawn_at'=>current_time('mysql')), array('id'=>$row->id));
        wp_die('<div style="max-width:620px;margin:60px auto;font:16px/1.6 sans-serif"><h1>Súhlas bol odvolaný</h1><p>Vašu e-mailovú adresu už nebudeme používať na zasielanie newslettera a marketingových informácií.</p><p>Odvolanie súhlasu nemá vplyv na zákonnosť spracúvania pred jeho odvolaním.</p></div>', 'digitalnydetox.sk');
    }

    private function result_key($score, $cfg) {
        foreach (array('low','medium','high') as $key) {
            if (isset($cfg['results'][$key]) && $score >= intval($cfg['results'][$key]['min']) && $score <= intval($cfg['results'][$key]['max'])) return $key;
        }
        return 'low';
    }

    public function admin_menu() {
        add_menu_page('Digitálny test','Digitálny test','manage_options','ddx-test',array($this,'admin_entries'),'dashicons-clipboard',56);
        add_submenu_page('ddx-test','Výsledky testov','Výsledky testov','manage_options','ddx-test',array($this,'admin_entries'));
        add_submenu_page('ddx-test','Insights','Insights','manage_options','ddx-test-insights',array($this,'admin_insights'));
        add_submenu_page('ddx-test','Statistics','Statistics','manage_options','ddx-test-statistics',array($this,'admin_statistics'));
        add_submenu_page('ddx-test','Drop-off analysis','Drop-off analysis','manage_options','ddx-test-dropoff',array($this,'admin_dropoff'));
        add_submenu_page('ddx-test','Nastavenia testu','Nastavenia testu','manage_options','ddx-test-settings',array($this,'admin_settings'));
        add_submenu_page('ddx-test','Newsletter súhlasy','Newsletter súhlasy','manage_options','ddx-test-marketing',array($this,'admin_marketing_consents'));
    }

    public function register_settings() {
        register_setting('ddx_test_group', self::OPTION, array($this,'sanitize_config'));
    }

    public function sanitize_config($input) {
        $defaults = $this->default_config();
        if (!is_array($input)) return $defaults;
        $out = $defaults;
        foreach (array('email_label','email_description','consent_label','marketing_label','terms','privacy_url','primary_color','background_color','font') as $key) {
            if (isset($input[$key])) $out[$key] = ($key === 'privacy_url') ? esc_url_raw($input[$key]) : sanitize_textarea_field($input[$key]);
        }
        foreach (array('questions','results') as $key) {
            if (isset($input[$key]) && is_string($input[$key])) {
                $decoded = json_decode(wp_unslash($input[$key]), true);
                if (is_array($decoded)) $out[$key] = $decoded;
            } elseif (isset($input[$key]) && is_array($input[$key])) $out[$key] = $input[$key];
        }
        return $out;
    }

    public function admin_settings() {
        if (!current_user_can('manage_options')) return;
        $cfg = $this->config();
        $qjson = wp_json_encode($cfg['questions'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $rjson = wp_json_encode($cfg['results'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        echo '<div class="wrap"><h1>Nastavenia digitálneho testu</h1><p>Otázky, odpovede a bodovanie sa dajú upravovať v JSON editore. Pred úpravou odporúčame exportovať nastavenia alebo si skopírovať pôvodný obsah.</p><form method="post" action="options.php">';
        settings_fields('ddx_test_group');
        echo '<h2>Otázky a odpovede</h2><textarea name="'.esc_attr(self::OPTION).'[questions]" rows="22" style="width:100%;font-family:monospace">'.esc_textarea($qjson).'</textarea>';
        echo '<h2>Výsledkové kategórie</h2><textarea name="'.esc_attr(self::OPTION).'[results]" rows="22" style="width:100%;font-family:monospace">'.esc_textarea($rjson).'</textarea>';
        echo '<h2>Vzhľad a texty</h2><table class="form-table"><tr><th>Primárna farba</th><td><input name="'.esc_attr(self::OPTION).'[primary_color]" value="'.esc_attr($cfg['primary_color']).'" /></td></tr><tr><th>Farba pozadia</th><td><input name="'.esc_attr(self::OPTION).'[background_color]" value="'.esc_attr($cfg['background_color']).'" /></td></tr><tr><th>Font</th><td><input name="'.esc_attr(self::OPTION).'[font]" value="'.esc_attr($cfg['font']).'" /></td></tr><tr><th>Označenie e-mailu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[email_label]" value="'.esc_attr($cfg['email_label']).'" /></td></tr><tr><th>Popis e-mailu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[email_description]" value="'.esc_attr($cfg['email_description']).'" /></td></tr><tr><th>Potvrdenie podmienok</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[consent_label]" value="'.esc_attr($cfg['consent_label']).'" /></td></tr><tr><th>Text marketingového súhlasu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[marketing_label]" value="'.esc_attr($cfg['marketing_label']).'" /></td></tr><tr><th>URL zásad ochrany súkromia</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[privacy_url]" value="'.esc_attr($cfg['privacy_url']).'" /></td></tr><tr><th>Podmienky používania</th><td><textarea name="'.esc_attr(self::OPTION).'[terms]" rows="8" class="large-text">'.esc_textarea($cfg['terms']).'</textarea></td></tr></table>';
        submit_button('Uložiť nastavenia'); echo '</form><p><strong>Shortcode:</strong> <code>[digitalny_detox_test]</code></p></div>';
    }

    public function delete_entries() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        check_admin_referer('ddx_delete_entries');
        global $wpdb;
        if (!empty($_POST['delete_all'])) { $deleted = $wpdb->query("DELETE FROM {$this->table()}"); wp_safe_redirect(add_query_arg(array('page'=>'ddx-test','ddx_deleted'=>max(0,(int)$deleted)), admin_url('admin.php'))); exit; }
        $ids = isset($_POST['entry_ids']) ? array_values(array_filter(array_map('absint', (array)$_POST['entry_ids']))) : array();
        if (!$ids) { wp_safe_redirect(admin_url('admin.php?page=ddx-test&ddx_deleted=0')); exit; }
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $deleted = $wpdb->query($wpdb->prepare("DELETE FROM {$this->table()} WHERE id IN ($placeholders)", $ids));
        wp_safe_redirect(add_query_arg(array('page'=>'ddx-test','ddx_deleted'=>max(0,(int)$deleted)), admin_url('admin.php'))); exit;
    }

    public function admin_marketing_consents() {
        if (!current_user_can('manage_options')) return;
        global $wpdb;
        $table = $wpdb->prefix . 'ddx_test_marketing';
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY consented_at DESC LIMIT 1000");
        $active = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE withdrawn_at IS NULL");
        echo '<div class="wrap"><h1>Newsletter – udelené súhlasy</h1>';
        echo '<p><strong>Aktívne súhlasy:</strong> ' . esc_html($active) . '</p>';
        echo '<p>Táto evidencia obsahuje iba adresy, pri ktorých respondent samostatne a dobrovoľne zaškrtol súhlas s newsletterom. Záznam o súhlase je oddelený od odpovedí a výsledkov testu.</p>';
        echo '<p><a class="button button-primary" href="' . esc_url(admin_url('admin-post.php?action=ddx_export_marketing_csv')) . '">Exportovať evidenciu súhlasov CSV</a></p>';
        echo '<table class="widefat striped"><thead><tr><th>E-mail</th><th>Udelený súhlas</th><th>Verzia súhlasu</th><th>Znenie súhlasu</th><th>Stav</th><th>Odvolanie</th></tr></thead><tbody>';
        if ($rows) foreach ($rows as $row) {
            $token = wp_hash($row->session_id . '|' . $row->email . '|' . $row->consented_at);
            $url = add_query_arg(array('action'=>'ddx_unsubscribe','sid'=>$row->session_id,'token'=>$token), admin_url('admin-post.php'));
            echo '<tr><td>' . esc_html($row->email) . '</td><td>' . esc_html($row->consented_at) . '</td><td>' . esc_html($row->consent_version) . '</td><td>' . esc_html($row->consent_text) . '</td><td>' . (empty($row->withdrawn_at) ? '<span style="color:#18753b">Aktívny</span>' : '<span style="color:#777">Odvolaný ' . esc_html($row->withdrawn_at) . '</span>') . '</td><td><a href="' . esc_url($url) . '" target="_blank" rel="noopener">Odkaz na odvolanie</a></td></tr>';
        } else echo '<tr><td colspan="6">Zatiaľ nebol udelený žiadny marketingový súhlas.</td></tr>';
        echo '</tbody></table><p class="description">Záznamy o udelených súhlasoch sa uchovávajú oddelene od výsledkov testu. Po odvolaní súhlasu sa dôkaz o jeho udelení uchováva ešte 4 roky; následne sa automaticky vymaže. Aktívne súhlasy zostávajú evidované do odvolania.</p></div>';
    }

    public function export_marketing_csv() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        global $wpdb;
        $table = $wpdb->prefix . 'ddx_test_marketing';
        $rows = $wpdb->get_results("SELECT session_id, email, consented_at, consent_version, consent_text, withdrawn_at FROM $table ORDER BY consented_at DESC", ARRAY_A);
        nocache_headers(); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=digitalny-detox-newsletter-suhlasy.csv');
        $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, array('email','consented_at','consent_version','consent_text','withdrawn_at','status','unsubscribe_url'), ';');
        foreach ($rows as $row) {
            $token = wp_hash($row['session_id'] . '|' . $row['email'] . '|' . $row['consented_at']);
            $unsubscribe_url = add_query_arg(array('action'=>'ddx_unsubscribe','sid'=>$row['session_id'],'token'=>$token), admin_url('admin-post.php'));
            fputcsv($out, array($row['email'],$row['consented_at'],$row['consent_version'],$row['consent_text'],$row['withdrawn_at'],$row['withdrawn_at'] ? 'withdrawn' : 'active',$unsubscribe_url), ';');
        }
        fclose($out); exit;
    }

    public function admin_entries() {
        if (!current_user_can('manage_options')) return;
        global $wpdb; $table=$this->table();
        $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY started_at DESC LIMIT 500");
        $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
        $completed=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status IN ('completed','imported_complete')");
        $completed_plugin=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE source='plugin' AND status='completed'");
        $started=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE source='plugin' AND first_answer_at IS NOT NULL");
        $abandoned=max(0,$started-$completed_plugin);
        echo '<div class="wrap"><h1>Výsledky testov</h1>';
        if (isset($_GET['ddx_deleted'])) echo '<div class="notice notice-success"><p>Vymazané záznamy: '.intval($_GET['ddx_deleted']).'.</p></div>';
        echo '<p><strong>Všetky záznamy:</strong> '.esc_html($total).' &nbsp; <strong>Dokončené (vrátane importu):</strong> '.esc_html($completed).' &nbsp; <strong>Začaté relácie pluginu:</strong> '.esc_html($started).' &nbsp; <strong>Nedokončené:</strong> '.esc_html($abandoned).' &nbsp; <strong>Miera dokončenia (plugin):</strong> '.esc_html($started ? round($completed_plugin/$started*100,1) : 0).'%</p>';
        echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin-post.php?action=ddx_export_csv')).'">Exportovať CSV</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=ddx-test-insights')).'">Otvoriť Insights</a></p>';
        echo '<h2>Import historických výsledkov z forms.app</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data">';
        echo '<input type="hidden" name="action" value="ddx_import_formsapp">'; wp_nonce_field('ddx_import_formsapp');
        echo '<input type="file" name="formsapp_csv" accept=".csv,text/csv" required> '; submit_button('Importovať CSV', 'secondary', 'submit', false);
        echo '<p class="description">Importuje CSV export z forms.app. Už importované Submission ID sa preskočia. Pôvodné skóre sa nemení; prázdne skóre zostane nevyhodnotené.</p></form>';
        if (isset($_GET['ddx_imported'])) echo '<div class="notice notice-success"><p>Import dokončený. Importované: '.intval($_GET['ddx_imported']).', preskočené: '.intval($_GET['ddx_skipped']).', chyby: '.intval($_GET['ddx_errors']).'.</p></div>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; echo '<input type="hidden" name="action" value="ddx_delete_entries">'; wp_nonce_field('ddx_delete_entries');
        echo '<p><button type="submit" class="button button-secondary" onclick="return confirm(&quot;Naozaj chcete vymazať označené záznamy? Túto akciu nemožno vrátiť späť.&quot;)">Vymazať označené</button> <button type="submit" name="delete_all" value="1" class="button button-link-delete" onclick="return confirm(&quot;Naozaj chcete vymazať VŠETKY záznamy vrátane importovaných výsledkov? Túto akciu nemožno vrátiť späť.&quot;)">Vymazať všetky záznamy</button></p>';
        echo '<table class="widefat striped"><thead><tr><td class="check-column">Označiť</td><th>Dátum začatia</th><th>E-mail</th><th>Stav</th><th>Posledný krok</th><th>Skóre</th><th>Výsledok</th><th>Zdroj</th><th>Posledná aktivita</th></tr></thead><tbody>';
        if ($rows) foreach ($rows as $row) {
            $answers=json_decode($row->answers,true); if (!is_array($answers)) $answers=array();
            $status=$row->status==='completed'?'Dokončený':($row->status==='imported_incomplete'?'Importovaný – neúplný':($row->status==='imported_complete'?'Importovaný – dokončený':($row->status==='viewed'?'Iba zobrazenie':(strtotime($row->updated_at) < time()-1800 ? 'Opustený / neaktívny':'Rozpracovaný'))));
            $step = count($answers) . ' / '.count($this->config()['questions']);
            $score_display = ($row->score >= 0 && in_array($row->status, array('completed','imported_complete','imported_incomplete'), true)) ? $row->score : '—';
            $result_label = ($row->result_key && isset($this->config()['results'][$row->result_key]['title'])) ? $this->config()['results'][$row->result_key]['title'] : '—';
            echo '<tr><th class="check-column"><input class="ddx-entry-check" type="checkbox" name="entry_ids[]" value="'.intval($row->id).'"></th><td>'.esc_html($row->started_at).'</td><td>'.esc_html($row->email ?: '—').'</td><td>'.esc_html($status).'</td><td>'.esc_html($step).'</td><td>'.esc_html($score_display).'</td><td>'.esc_html($result_label).'</td><td>'.esc_html($row->source==='formsapp'?'forms.app':'Plugin').'</td><td>'.esc_html($row->updated_at).'</td></tr>';
            if ($answers) echo '<tr><td colspan="9"><details><summary>Zobraziť odpovede</summary><ol>'; foreach ($answers as $i=>$answer) echo '<li>'.esc_html(isset($this->config()['questions'][$i]['text'])?$this->config()['questions'][$i]['text']:'Otázka').' — <strong>'.esc_html($answer).'</strong></li>'; if ($answers) echo '</ol></details></td></tr>';
        } else echo '<tr><td colspan="9">Zatiaľ neboli zaznamenané žiadne vyplnenia.</td></tr>';
        echo '</tbody></table></form><p class="description">Zobrazuje sa najviac 500 posledných záznamov. Vymazanie odstráni záznam aj z analytiky. Historické importy nemajú údaje o zariadeniach ani priebehu vypĺňania.</p></div>';
    }

    private function analytics_period() {
        $period = isset($_GET['period']) ? sanitize_key($_GET['period']) : '30';
        if (!in_array($period, array('7','30','90','all'), true)) $period='30';
        $device = isset($_GET['device']) ? sanitize_key($_GET['device']) : 'all';
        if (!in_array($device, array('all','mobile','desktop','tablet'), true)) $device='all';
        $sql = '';
        if ($period !== 'all') { global $wpdb; $date = gmdate('Y-m-d H:i:s', time() - ((int)$period * DAY_IN_SECONDS)); $sql .= $wpdb->prepare(' AND started_at >= %s', get_date_from_gmt($date)); }
        if ($device !== 'all') { global $wpdb; $sql .= $wpdb->prepare(' AND device = %s', $device); }
        return array($period, $sql, $device);
    }

    private function analytics_header($title) {
        list($period, $date_sql, $device) = $this->analytics_period();
        echo '<div class="wrap"><h1>'.esc_html($title).'</h1><nav class="nav-tab-wrapper"><a class="nav-tab" href="'.esc_url(add_query_arg(array('page'=>'ddx-test-insights','period'=>$period,'device'=>$device),admin_url('admin.php'))).'">Insights</a><a class="nav-tab" href="'.esc_url(add_query_arg(array('page'=>'ddx-test-statistics','period'=>$period,'device'=>$device),admin_url('admin.php'))).'">Statistics</a><a class="nav-tab" href="'.esc_url(add_query_arg(array('page'=>'ddx-test-dropoff','period'=>$period,'device'=>$device),admin_url('admin.php'))).'">Drop-off analysis</a></nav>';
        echo '<form method="get" style="margin:16px 0"><input type="hidden" name="page" value="'.esc_attr(sanitize_key($_GET['page'] ?? 'ddx-test-insights')).'"><label for="ddx-period">Obdobie: </label><select id="ddx-period" name="period"><option value="7" '.selected($period,'7',false).'>Posledných 7 dní</option><option value="30" '.selected($period,'30',false).'>Posledných 30 dní</option><option value="90" '.selected($period,'90',false).'>Posledných 90 dní</option><option value="all" '.selected($period,'all',false).'>Celé obdobie</option></select> <label for="ddx-device" style="margin-left:12px">Zariadenie: </label><select id="ddx-device" name="device"><option value="all" '.selected($device,'all',false).'>Všetky</option><option value="mobile" '.selected($device,'mobile',false).'>Mobil</option><option value="desktop" '.selected($device,'desktop',false).'>Desktop</option><option value="tablet" '.selected($device,'tablet',false).'>Tablet</option></select> <button class="button">Použiť</button></form>';
    }

    private function analytics_bar($label, $count, $max, $percent_base = null) {
        $pct = $max > 0 ? min(100, round($count / $max * 100, 1)) : 0;
        $suffix = ($percent_base !== null && $percent_base > 0) ? ' ('.round($count / $percent_base * 100, 1).'%)' : '';
        echo '<div style="margin:9px 0"><div style="display:flex;justify-content:space-between;gap:12px"><span>'.esc_html($label).'</span><strong>'.esc_html($count.$suffix).'</strong></div><div style="height:9px;background:#e5e7eb;border-radius:8px;overflow:hidden"><div style="height:9px;width:'.$pct.'%;background:#d6a500"></div></div></div>';
    }

    public function admin_insights() {
        if (!current_user_can('manage_options')) return; global $wpdb; $t=$this->table(); list($period,$date_sql)=$this->analytics_period();
        $views=(int)$wpdb->get_var("SELECT COALESCE(SUM(page_views),0) FROM $t WHERE source='plugin' $date_sql");
        $sessions=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE source='plugin' AND first_answer_at IS NOT NULL $date_sql");
        $completed=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE source='plugin' AND status='completed' $date_sql");
        $incomplete=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE source='plugin' AND first_answer_at IS NOT NULL AND status<>'completed' $date_sql");
        $avg=(float)$wpdb->get_var("SELECT AVG(TIMESTAMPDIFF(SECOND,first_answer_at,completed_at)) FROM $t WHERE source='plugin' AND status='completed' AND first_answer_at IS NOT NULL AND completed_at IS NOT NULL $date_sql");
        $this->analytics_header('Insights – analytika testu');
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;max-width:1100px">';
        foreach (array('Zobrazenia testu'=>$views,'Začaté testy'=>$sessions,'Dokončené testy'=>$completed,'Nedokončené testy'=>$incomplete,'Miera dokončenia'=>($sessions?round($completed/$sessions*100,1):0).'%','Priemerný čas vyplnenia'=>($avg?gmdate($avg>=3600?'G\h i\m':'i\m s\s',(int)$avg):'—')) as $label=>$value) echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px"><div style="color:#646970">'.esc_html($label).'</div><div style="font-size:26px;font-weight:600;margin-top:8px">'.esc_html($value).'</div></div>';
        $trend=$wpdb->get_results("SELECT DATE(started_at) AS day, SUM(page_views) AS views, SUM(first_answer_at IS NOT NULL) AS starts, SUM(status='completed') AS completed FROM $t WHERE source='plugin' $date_sql GROUP BY DATE(started_at) ORDER BY day DESC LIMIT 30");
        echo '</div><section style="max-width:1100px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;margin-top:24px"><h2>Vývoj v čase</h2>';
        if ($trend) { echo '<table class="widefat striped"><thead><tr><th>Dátum</th><th>Zobrazenia</th><th>Začaté</th><th>Dokončené</th></tr></thead><tbody>'; foreach ($trend as $day) echo '<tr><td>'.esc_html($day->day).'</td><td>'.intval($day->views).'</td><td>'.intval($day->starts).'</td><td>'.intval($day->completed).'</td></tr>'; echo '</tbody></table>'; } else echo '<p>Zatiaľ nie sú dostupné údaje.</p>';
        echo '</section><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;max-width:1100px;margin-top:24px">';
        foreach (array('Dokončenie podľa zariadenia'=>'device','Dokončenie podľa OS'=>'os') as $heading=>$field) {
            $segments=$wpdb->get_results("SELECT `$field` AS label, SUM(page_views) AS views, SUM(first_answer_at IS NOT NULL) AS starts, SUM(status='completed') AS completed FROM $t WHERE source='plugin' AND page_views>0 AND `$field` IS NOT NULL AND `$field`<>'' $date_sql GROUP BY `$field` ORDER BY views DESC");
            echo '<section style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;margin-top:20px"><h2 style="margin-top:0">'.esc_html($heading).'</h2>';
            if ($segments) { echo '<table class="widefat striped"><thead><tr><th>Kategória</th><th>Zobrazenia testu</th><th>Začaté</th><th>Dokončené</th><th>Miera dokončenia</th></tr></thead><tbody>'; foreach ($segments as $segment) { $rate=(int)$segment->starts ? round((int)$segment->completed/(int)$segment->starts*100,1).'%' : '—'; echo '<tr><td>'.esc_html($segment->label).'</td><td>'.intval($segment->views).'</td><td>'.intval($segment->starts).'</td><td>'.intval($segment->completed).'</td><td>'.esc_html($rate).'</td></tr>'; } echo '</tbody></table>'; }
            else echo '<p>Zatiaľ nie sú dostupné údaje.</p>';
            echo '</section>';
        }
        foreach (array('Zariadenia'=>'device','Operačné systémy'=>'os','Prehliadače'=>'browser','Krajiny'=>'country','Regióny'=>'region','Mestá'=>'city') as $heading=>$field) {
            $items=$wpdb->get_results("SELECT `$field` AS label, COUNT(*) AS n FROM $t WHERE source='plugin' AND page_views > 0 AND `$field` IS NOT NULL AND `$field`<>'' $date_sql GROUP BY `$field` ORDER BY n DESC LIMIT 10");
            echo '<section style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px"><h2 style="margin-top:0">'.esc_html($heading).'</h2>';
            if ($items) { $max=(int)$items[0]->n; foreach ($items as $item) $this->analytics_bar($item->label,(int)$item->n,$max); }
            else echo '<p>Zatiaľ nie sú dostupné údaje.</p>';
            echo '</section>';
        }
        echo '</div><p class="description" style="max-width:1100px;margin-top:18px">Zariadenie, OS a prehliadač sa určujú z User-Agent. Krajina sa získava z hlavičky Cloudflare CF-IPCountry. Mesto a región sa zobrazia len vtedy, ak ich Cloudflare posiela v hlavičkách CF-IPCity a CF-Region. IP adresa sa do databázy neukladá. Zobrazenia a návštevy sa zbierajú od verzie 0.4.0; historické importy z forms.app sa do týchto metrík nezapočítavajú.</p></div>';
    }

    public function admin_statistics() {
        if (!current_user_can('manage_options')) return; global $wpdb; $t=$this->table(); list($period,$date_sql)=$this->analytics_period(); $cfg=$this->config();
        $this->analytics_header('Statistics – štatistiky odpovedí');
        $rows=$wpdb->get_results("SELECT answers FROM $t WHERE answers IS NOT NULL AND answers<>'' AND answers<>'{}' $date_sql");
        echo '<div style="max-width:1100px">';
        foreach ($cfg['questions'] as $i=>$q) {
            $counts=array(); $total=0;
            foreach ($q['options'] as $option) $counts[$option['label']]=0;
            foreach ($rows as $row) { $a=json_decode($row->answers,true); if (isset($a[$i])) { $v=(string)$a[$i]; foreach ($counts as $label=>$n) if (strtolower(remove_accents($label)) === strtolower(remove_accents($v))) { $counts[$label]++; $total++; break; } } }
            echo '<section style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;margin:14px 0"><h2>'.esc_html(($i+1).'. '.$q['text']).'</h2><p class="description">Počet odpovedí: '.intval($total).'</p>';
            foreach ($counts as $label=>$n) $this->analytics_bar($label,$n,$total,$total);
            echo '</section>';
        }
        echo '</div></div>';
    }

    public function admin_dropoff() {
        if (!current_user_can('manage_options')) return; global $wpdb; $t=$this->table(); list($period,$date_sql)=$this->analytics_period(); $totalq=count($this->config()['questions']);
        $started=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE source='plugin' AND first_answer_at IS NOT NULL $date_sql");
        $completed=(int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE source='plugin' AND status='completed' $date_sql");
        $this->analytics_header('Drop-off analysis – odchody z testu');
        echo '<div style="max-width:1000px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px"><p>Analýza zahŕňa relácie, v ktorých návštevník odpovedal aspoň na jednu otázku. Zobrazenia bez prvej odpovede sa počítajú v Insights, nie ako začaté testy.</p><p><strong>Začaté testy:</strong> '.intval($started).' &nbsp; <strong>Dokončené:</strong> '.intval($completed).' &nbsp; <strong>Nedokončené:</strong> '.intval(max(0,$started-$completed)).'</p>';
        if ($started) {
            $max=$started;
            for ($i=1;$i<=$totalq;$i++) {
                $reached=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE source='plugin' AND first_answer_at IS NOT NULL AND last_question >= %d $date_sql",$i));
                $lost=max(0,($i===1?$started:(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE source='plugin' AND first_answer_at IS NOT NULL AND last_question >= %d $date_sql",$i-1)))-$reached);
                $pct=round($reached/$started*100,1);
                echo '<div style="margin:16px 0"><div style="display:flex;justify-content:space-between;gap:12px"><strong>Otázka '.intval($i).'</strong><span>'.intval($reached).' návštevníkov ('.$pct.' %)'.($lost?' · odchodov pred ňou: '.intval($lost):'').'</span></div><div style="height:12px;background:#e5e7eb;border-radius:8px;overflow:hidden"><div style="height:12px;width:'.min(100,$pct).'%;background:#d6a500"></div></div></div>';
            }
            echo '<p><strong>Dokončenie testu:</strong> '.round($completed/$started*100,1).'%</p>';
        } else echo '<p>Zatiaľ nie sú dostupné relácie so začatou odpoveďou. Údaje sa začnú zbierať po nasadení verzie 0.4.0.</p>';
        echo '</div><p class="description">Presnosť drop-off analýzy sa vzťahuje na relácie zaznamenané verziou 0.4.0 a novšou. Návštevník, ktorý zavrie stránku bez ďalšej interakcie, sa prejaví podľa poslednej uloženej odpovede.</p></div>';
    }

    public function import_formsapp() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        check_admin_referer('ddx_import_formsapp');
        if (empty($_FILES['formsapp_csv']['tmp_name']) || !is_uploaded_file($_FILES['formsapp_csv']['tmp_name'])) wp_die('CSV súbor sa nepodarilo načítať.');
        $fh = fopen($_FILES['formsapp_csv']['tmp_name'], 'r');
        if (!$fh) wp_die('CSV súbor sa nepodarilo otvoriť.');
        $headers = fgetcsv($fh, 0, ',');
        if (!$headers) { fclose($fh); wp_die('CSV súbor je prázdny.'); }
        $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', $headers[0]);
        $header_map = array_flip($headers);
        $question_headers = array(
            'Kontrolujem si správy/aktivity na mobile hneď po zobudení?',
            'Telefón mám stále po ruke, mám ho aj pri posteli.',
            'Cítim nutkanie skontrolovať si mobil aj bez toho, aby mi prišla notifikácia.',
            'Odkladám úlohy a povinnosti na úkor času pred obrazovkou.',
            'Nedokážem sa sústrediť pri práci/štúdiu kvôli online vyrušeniam.',
            'Chodievam spať neskôr, pretože som dlhšie za počítačom alebo na mobile.',
            'Mobil používam aj pri prechádzke alebo jazde autom.',
            'Jedávam s mobilom v ruke alebo pred televízorom, či notebookom.',
            'Keď som bez mobilu, bývam nervózny.',
            'Pred okolím ukrývam moje aktivity na mobile.',
            'Denne trávim na sociálnych sieťach viac času, než by som chcel.',
            'Cítim sa zle, keď mi niečo unikne (novinky/správy).',
            'Myslím si, že trávim na mobile viac času, než je pre mňa zdravé.'
        );
        $required = array_merge($question_headers, array('E-mail','Total Score','Submission Date','Submission ID'));
        foreach ($required as $col) {
            if (!array_key_exists($col, $header_map)) { fclose($fh); wp_die('CSV nemá očakávaný stĺpec: '.esc_html($col)); }
        }
        global $wpdb; $table = $this->table(); $cfg = $this->config();
        $imported = 0; $skipped = 0; $errors = 0;
        while (($row = fgetcsv($fh, 0, ',')) !== false) {
            if (count($row) < count($headers)) { $row = array_pad($row, count($headers), ''); }
            $get = function($name) use ($header_map, $row) { return isset($header_map[$name], $row[$header_map[$name]]) ? trim((string)$row[$header_map[$name]]) : ''; };
            $external_id = sanitize_text_field($get('Submission ID'));
            $email = sanitize_email($get('E-mail'));
            if (!$external_id || !$email || !is_email($email)) { $errors++; continue; }
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE external_id=%s", $external_id));
            if ($exists) { $skipped++; continue; }
            $answers = array(); $answered = 0;
            foreach ($question_headers as $i=>$question) {
                $answer = $get($question);
                if ($answer === '') continue;
                $answers[$i] = $answer; $answered++;
            }
            $score_raw = $get('Total Score');
            $score = ($score_raw !== '' && is_numeric($score_raw)) ? intval($score_raw) : -1;
            if ($score > 32 || $score < -1) { $errors++; continue; }
            $result_key = $score >= 0 ? $this->result_key($score, $cfg) : null;
            $date_raw = $get('Submission Date');
            $date = DateTime::createFromFormat('!d/m/Y, H:i:s', $date_raw);
            if (!$date) $date = DateTime::createFromFormat('!d/m/Y H:i:s', $date_raw);
            if (!$date) { $errors++; continue; }
            $created = $date->format('Y-m-d H:i:s');
            $complete = ($score >= 0 && $answered === 13);
            $session_id = 'formsapp-' . substr(hash('sha256', $external_id), 0, 48);
            $inserted = $wpdb->insert($table, array(
                'session_id'=>$session_id, 'source'=>'formsapp', 'external_id'=>$external_id,
                'email'=>$email, 'answers'=>wp_json_encode($answers), 'current_step'=>$answered,
                'score'=>$score, 'result_key'=>$result_key, 'status'=>$complete ? 'imported_complete' : 'imported_incomplete',
                'consent'=>($get('Terms & conditions') !== '' ? 1 : 0), 'started_at'=>$created,
                'updated_at'=>$created, 'completed_at'=>$complete ? $created : null
            ));
            if ($inserted) $imported++; else $errors++;
        }
        fclose($fh);
        $url = add_query_arg(array('page'=>'ddx-test','ddx_imported'=>$imported,'ddx_skipped'=>$skipped,'ddx_errors'=>$errors), admin_url('admin.php'));
        wp_safe_redirect($url); exit;
    }

    public function export_csv() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table()} ORDER BY started_at DESC", ARRAY_A);
        nocache_headers(); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=digitalny-detox-test-vysledky.csv');
        $out=fopen('php://output','w'); fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out,array('session_id','source','external_id','email','status','started_at','updated_at','completed_at','first_answer_at','page_views','last_question','device','os','browser','country','region','city','current_step','score','result_key','terms_acknowledged','marketing_consent','marketing_consent_at','email_sent_at','answers'),';');
        foreach ($rows as $row) fputcsv($out,array($row['session_id'],$row['source'],$row['external_id'],$row['email'],$row['status'],$row['started_at'],$row['updated_at'],$row['completed_at'],$row['first_answer_at'],$row['page_views'],$row['last_question'],$row['device'],$row['os'],$row['browser'],$row['country'],$row['region'],$row['city'],$row['current_step'],$row['score'] >= 0 ? $row['score'] : '',$row['result_key'],$row['consent'],$row['marketing_consent'],$row['marketing_consent_at'],$row['email_sent_at'],$row['answers']),';');
        fclose($out); exit;
    }
}
DDX_Test_Plugin::instance();

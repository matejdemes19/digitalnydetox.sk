(function(){
  'use strict';
  function ready(fn){if(document.readyState!=='loading')fn();else document.addEventListener('DOMContentLoaded',fn);}
  ready(function(){
    var root=document.getElementById('ddx-test-app');
    if(!root||!window.DDXTest)return;
    var cfg=window.DDXTest,total=cfg.questions.length,step=0,answers={},email='',consent=false,marketingConsent=false,busy=false,advanceTimer=null;
    var sidKey='ddx_test_session_v1',session='';
    try{session=localStorage.getItem(sidKey)||'';}catch(e){}
    if(!/^[a-f0-9-]{32,36}$/i.test(session)){
      session=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){var r=Math.random()*16|0;return(c==='x'?r:(r&3|8)).toString(16);});
      try{localStorage.setItem(sidKey,session);}catch(e){}
    }
    root.style.setProperty('--ddx-yellow',cfg.primaryColor||'#FEBF00');
    root.style.background=cfg.backgroundColor||'#fff';
    if(cfg.font)root.style.fontFamily='"'+String(cfg.font).replace(/[^a-zA-Z0-9 ,_-]/g,'')+'",system-ui,sans-serif';
    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]);});}
    function post(event){
      var fd=new FormData();
      fd.append('action','ddx_save_progress');fd.append('nonce',cfg.nonce);fd.append('session_id',session);
      var answeredIndexes=Object.keys(answers).map(function(k){return parseInt(k,10)+1;});var lastAnswered=answeredIndexes.length?Math.max.apply(null,answeredIndexes):0;
      fd.append('answers',JSON.stringify(answers));fd.append('current_step',step);fd.append('last_question',lastAnswered);fd.append('event',event||'progress');fd.append('email',email);
      fd.append('consent',consent?'1':'0');fd.append('marketing_consent',marketingConsent?'1':'0');fd.append('complete',event==='complete'?'1':'0');
      return fetch(cfg.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();});
    }
    function brand(){var logo=cfg.logoUrl?'<img class="ddx-brand-logo" src="'+esc(cfg.logoUrl)+'" alt="digitalnydetox.sk">':'<span class="ddx-brand-name">digitalnydetox.sk</span>';return '<div class="ddx-brand">'+logo+'<span class="ddx-brand-divider" aria-hidden="true"></span><span class="ddx-brand-context">Test digitálnej záťaže</span></div>';}
    function progress(){
      var html='<div class="ddx-step-row"><span>Váš pokrok</span><strong>Otázka '+(step+1)+' z '+total+'</strong></div><div class="ddx-progress" role="progressbar" aria-valuemin="0" aria-valuemax="'+total+'" aria-valuenow="'+(step+1)+'" aria-label="Priebeh testu">';
      for(var i=0;i<total;i++)html+='<span class="'+(i<=step?'is-done':'')+'"></span>';
      return html+'</div>';
    }
    function goNext(){
      if(answers[step]===undefined)return;
      if(step<total-1){step++;renderQuestion();post('progress').catch(function(){});}
      else renderEmail();
    }
    function renderQuestion(){
      if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}
      var q=cfg.questions[step],selected=answers[step];
      var html=brand()+progress()+'<p class="ddx-kicker">Zamyslite sa nad svojimi návykmi</p><h2>'+esc(q.text)+'</h2><div class="ddx-options">';
      q.options.forEach(function(o){html+='<button type="button" class="ddx-option '+(selected===o.label?'is-selected':'')+'" data-answer="'+esc(o.label)+'" aria-pressed="'+(selected===o.label?'true':'false')+'"><span class="ddx-radio" aria-hidden="true"></span><span>'+esc(o.label)+'</span></button>';});
      html+='</div><div class="ddx-actions">'+(step>0?'<button type="button" class="ddx-btn ddx-btn-secondary" data-back>Späť</button>':'<span></span>')+'<button type="button" class="ddx-btn ddx-btn-primary" data-next '+(selected===undefined?'disabled':'')+'>Pokračovať</button></div><div class="ddx-hint" aria-live="polite">Vyberte odpoveď. Na ďalšiu otázku prejdete automaticky.</div><div class="ddx-error" role="alert"></div>';
      root.innerHTML=html;
      root.querySelectorAll('[data-answer]').forEach(function(btn){btn.addEventListener('click',function(){
        if(busy)return;
        if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}
        answers[step]=btn.getAttribute('data-answer');
        root.querySelectorAll('[data-answer]').forEach(function(option){var chosen=option===btn;option.classList.toggle('is-selected',chosen);option.setAttribute('aria-pressed',chosen?'true':'false');});
        var next=root.querySelector('[data-next]');if(next)next.disabled=false;
        var hint=root.querySelector('.ddx-hint');if(hint)hint.textContent='Odpoveď uložená';
        post('answer').catch(function(){});
        advanceTimer=setTimeout(goNext,360);
      });});
      var next=root.querySelector('[data-next]');
      next.addEventListener('click',function(){if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}goNext();});
      var back=root.querySelector('[data-back]');
      if(back)back.addEventListener('click',function(){if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}step=Math.max(0,step-1);renderQuestion();});
    }
    function renderEmail(){
      if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}
      var privacy=cfg.privacyUrl?'<a href="'+esc(cfg.privacyUrl)+'" target="_blank" rel="noopener">Zásady ochrany osobných údajov</a>':'Zásady ochrany osobných údajov';
      var html=brand()+'<p class="ddx-kicker">Test je dokončený</p>'+progress()+'<h2>'+esc(cfg.strings.emailTitle)+'</h2><p class="ddx-email-note">Zadajte e-mailovú adresu, na ktorú vám pošleme vaše skóre, kategóriu výsledku a stručné odporúčania. E-mailová adresa je potrebná na doručenie vyhodnotenia.</p><label for="ddx-email">'+esc(cfg.emailLabel)+' <span aria-hidden="true">*</span></label><input id="ddx-email" class="ddx-field" type="email" autocomplete="email" required placeholder="'+esc(cfg.emailDescription)+'" value="'+esc(email)+'"><div class="ddx-terms">'+esc(cfg.terms)+'</div><label class="ddx-consent"><input type="checkbox" id="ddx-consent" '+(consent?'checked':'')+'><span>'+esc(cfg.consentLabel)+'</span></label><label class="ddx-consent ddx-marketing"><input type="checkbox" id="ddx-marketing" '+(marketingConsent?'checked':'')+'><span>'+esc(cfg.marketingLabel||'Súhlasím so zasielaním newslettera a marketingových informácií. Súhlas môžem kedykoľvek odvolať.')+'</span></label><p class="ddx-privacy-note">Informácie o prevádzkovateľovi, účeloch a právnych základoch spracúvania, dobe uchovávania a vašich právach nájdete v '+privacy+'.</p><div class="ddx-actions"><button type="button" class="ddx-btn ddx-btn-secondary" data-back>Späť</button><button type="button" class="ddx-btn ddx-btn-primary" data-submit>'+esc(cfg.strings.finish)+'</button></div><div class="ddx-error" role="alert"></div>';
      root.innerHTML=html;
      root.querySelector('[data-back]').addEventListener('click',function(){step=total-1;renderQuestion();});
      root.querySelector('#ddx-email').addEventListener('change',function(){email=this.value.trim();post('progress').catch(function(){});});
      root.querySelector('#ddx-consent').addEventListener('change',function(){consent=this.checked;post('progress').catch(function(){});});
      root.querySelector('#ddx-marketing').addEventListener('change',function(){marketingConsent=this.checked;post('progress').catch(function(){});});
      root.querySelector('[data-submit]').addEventListener('click',function(){
        if(busy)return;
        email=root.querySelector('#ddx-email').value.trim();consent=root.querySelector('#ddx-consent').checked;marketingConsent=root.querySelector('#ddx-marketing').checked;
        var err=root.querySelector('.ddx-error');
        if(!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){err.textContent=cfg.strings.invalidEmail;return;}
        if(!consent){err.textContent=cfg.strings.consentRequired;return;}
        busy=true;err.textContent=cfg.strings.sending;
        post('complete').then(function(res){busy=false;if(!res.success){err.textContent=(res.data&&res.data.message)||cfg.strings.error;return;}renderResult(res.data);}).catch(function(){busy=false;err.textContent=cfg.strings.error;});
      });
    }
    function renderList(items){
      if(!Array.isArray(items)||!items.length)return '';
      return '<ul>'+items.map(function(item){return '<li>'+esc(item)+'</li>';}).join('')+'</ul>';
    }
    function renderResult(data){
      var r=data.result||{},score=Math.max(0,Math.min(32,parseInt(data.score,10)||0)),pct=Math.round(score/32*100);
      var key=data.result_key||'medium',tone=key==='low'?'low':(key==='high'?'high':'medium');
      var labels={low:'Nízke riziko',medium:'Stredné riziko',high:'Zvýšené riziko'};
      var recommendations={
        low:[['◉','Udržujte si dobré návyky','Pokračujte v tom, čo vám pomáha udržiavať rovnováhu.'],['☾','Nezabúdajte na offline čas','Zachovajte si chvíle bez telefónu, napríklad počas jedla alebo pred spaním.'],['▣','Všímajte si hodnotu','Priebežne sledujte, ktoré digitálne aktivity vám prinášajú skutočnú hodnotu.']],
        medium:[['♧','Obmedzte notifikácie','Vypnite upozornenia, ktoré nie sú dôležité alebo naliehavé.'],['☾','Nastavte večerný limit','Skúste prvých a posledných 30 minút dňa stráviť bez telefónu.'],['▣','Vyhraďte si offline čas','Určite si konkrétne časy na kontrolu správ a sociálnych sietí.']],
        high:[['♧','Obmedzte vyrušenia','Skontrolujte aplikácie a upozornenia, ktoré vás najčastejšie vyrušujú.'],['☾','Doprajte si pokojný večer','Skúste nechať telefón mimo spálne počas noci.'],['▣','Naplánujte si offline čas','Vytvorte si každý deň aspoň jeden blok času bez obrazovky.']]
      };
      var tips=recommendations[key]||recommendations.medium,points=Array.isArray(r.points)?r.points:[];
      var riskText=r.intro||(key==='low'?'Vaše odpovede naznačujú, že digitálne technológie máte prevažne pod kontrolou. Udržujte si návyky, ktoré vám vyhovujú.':(key==='medium'?'Vaše digitálne návyky si zaslúžia trochu pozornosti. Niektoré technológie môžu zasahovať do vášho času, sústredenia alebo oddychu.':'Vaše odpovede naznačujú, že digitálne návyky môžu výraznejšie zasahovať do každodenného života. Oplatí sa začať postupnými a konkrétnymi zmenami.'));if(r.detail)riskText+=' '+r.detail;
      var scale='<div class="ddx-score-scale" aria-label="Skóre '+score+' z 32 bodov"><div class="ddx-scale-track"><span class="ddx-scale-fill ddx-tone-'+tone+'" style="width:'+pct+'%"></span><span class="ddx-scale-marker ddx-marker-'+tone+'" style="left:'+pct+'%"></span></div><div class="ddx-scale-labels"><span>0</span><span>9</span><span>20</span><span>32</span></div><div class="ddx-scale-categories"><span class="ddx-scale-low">Nízke riziko</span><span class="ddx-scale-medium">Stredné riziko</span><span class="ddx-scale-high">Zvýšené riziko</span></div></div>';
      var html=brand()+'<header class="ddx-result-heading"><p class="ddx-kicker">VÝSLEDOK TESTU DIGITÁLNEJ ZÁŤAŽE</p><h2 id="ddx-result-title">Váš výsledok testu digitálnej záťaže</h2><p>Tu je váš osobný prehľad digitálnych návykov a odporúčania na zlepšenie.</p></header>';
      html+='<section class="ddx-result ddx-result-'+tone+'" aria-labelledby="ddx-result-title"><div class="ddx-score-overview"><div class="ddx-score-caption">VAŠE SKÓRE</div><div class="ddx-score-big"><strong>'+score+'</strong><span>/ 32 bodov</span></div>'+scale;
      html+='<div class="ddx-risk-card ddx-risk-card-'+tone+'"><div class="ddx-risk-symbol" aria-hidden="true">'+(tone==='low'?'✓':(tone==='medium'?'◎':'!'))+'</div><div><h3>'+esc(labels[key])+'</h3><p>'+esc(riskText)+'</p></div></div></div>';
      html+='<div class="ddx-insight-grid"><section class="ddx-insight ddx-insight-good"><div class="ddx-insight-icon">✓</div><div><h3>Čo sa vám darí</h3><p>Už tým, že ste sa pozreli na svoje digitálne návyky, robíte prvý krok k vedomejšiemu používaniu technológií.</p><ul>'+((key==='low'?points.slice(0,2):['Venujete pozornosť svojmu vzťahu k technológiám.']).map(function(x){return '<li>'+esc(x)+'</li>';}).join(''))+'</ul></div></section>';
      html+='<section class="ddx-insight ddx-insight-watch"><div class="ddx-insight-icon">◎</div><div><h3>Čomu venovať pozornosť</h3><p>'+(key==='low'?'Aj pri dobrých digitálnych návykoch pomáha priebežne sledovať, či vám technológie nechávajú dostatok priestoru na oddych.':'Pozrite sa na oblasti, ktoré sa vo vašich odpovediach objavili najčastejšie.')+'</p><ul>'+((key==='low'?['Udržujte si hranice pri používaní mobilu.']:points.slice(0,3)).map(function(x){return '<li>'+esc(x)+'</li>';}).join(''))+'</ul></div></section></div>';
      html+='<section class="ddx-recommendations ddx-recommendations-panel"><h3>3 KROKY K LEPŠEJ DIGITÁLNEJ ROVNOVÁHE</h3><div class="ddx-recommendation-grid">'+tips.map(function(t,i){return '<article class="ddx-recommendation"><span class="ddx-recommendation-icon" aria-hidden="true">'+t[0]+'</span><div class="ddx-recommendation-title"><b>'+(i+1)+'</b><strong>'+esc(t[1])+'</strong></div><p>'+esc(t[2])+'</p></article>';}).join('')+'</div></section>';
      if(r.profile_title){html+='<section class="ddx-profile"><div class="ddx-profile-art" aria-hidden="true"><div class="ddx-profile-paper"><span class="ddx-profile-mark">✳</span><strong>MOJ DIGITÁLNY<br>PROFIL</strong><div class="ddx-profile-bars"><i></i><i></i><i></i><i></i><i></i></div></div></div><div class="ddx-profile-content"><span class="ddx-profile-recommended">ODPORÚČANÉ</span><h3>Spoznajte svoj digitálny profil podrobnejšie</h3><p class="ddx-profile-description">Získajte podrobnejšiu analýzu vašich digitálnych návykov, identifikáciu rizikových oblastí a individuálne odporúčania na zlepšenie digitálnej rovnováhy.</p><ul><li>Detailná analýza</li><li>Personalizované odporúčania</li><li>Osobný PDF profil</li></ul><a class="ddx-cta" href="'+esc(r.url||'#')+'">Získať detailný profil <span aria-hidden="true">→</span></a></div></section>';}
      if(data.mail_sent===false)html+='<p class="ddx-mail-warning">Výsledok sa zobrazil na obrazovke, ale e-mail sa nepodarilo odoslať. Skontrolujte, prosím, adresu alebo nás kontaktujte.</p>';
      else html+='<p class="ddx-mail-success">Súhrn výsledku sme odoslali na zadanú e-mailovú adresu.</p>';
      html+='<p class="ddx-disclaimer">Výsledok je orientačný a slúži na informačné účely. Nenahrádza odborné ani zdravotné posúdenie.</p><div class="ddx-result-actions"><button type="button" class="ddx-btn ddx-btn-secondary" data-restart>Vyplniť test znova</button><a class="ddx-btn ddx-btn-primary" href="https://www.digitalnydetox.sk/">Späť na hlavnú stránku</a></div></section>';
      root.innerHTML=html;
      var restart=root.querySelector('[data-restart]');if(restart)restart.addEventListener('click',function(){try{localStorage.removeItem(sidKey);}catch(e){}window.location.reload();});
      try{localStorage.removeItem(sidKey);}catch(e){}
    }
    renderQuestion();post('view').catch(function(){});
  });
})();

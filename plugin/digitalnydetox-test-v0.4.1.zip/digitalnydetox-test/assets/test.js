(function(){
  'use strict';
  function ready(fn){if(document.readyState!=='loading')fn();else document.addEventListener('DOMContentLoaded',fn);}
  ready(function(){
    var root=document.getElementById('ddx-test-app');
    if(!root||!window.DDXTest)return;
    var cfg=window.DDXTest,total=cfg.questions.length,step=0,answers={},email='',consent=false,busy=false,advanceTimer=null;
    var sidKey='ddx_test_session_v1',session='';
    try{session=localStorage.getItem(sidKey)||'';}catch(e){}
    if(!/^[a-f0-9-]{32,36}$/i.test(session)){
      session=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){var r=Math.random()*16|0;return(c==='x'?r:(r&3|8)).toString(16);});
      try{localStorage.setItem(sidKey,session);}catch(e){}
    }
    root.style.setProperty('--ddx-yellow',cfg.primaryColor||'#FEBF00');
    root.style.background=cfg.backgroundColor||'#fff';
    if(cfg.font)root.style.fontFamily='"'+String(cfg.font).replace(/[^a-zA-Z0-9 ,_-]/g,'')+'",system-ui,sans-serif';
    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]);});}
    function post(event){
      var fd=new FormData();
      fd.append('action','ddx_save_progress');fd.append('nonce',cfg.nonce);fd.append('session_id',session);
      var answeredIndexes=Object.keys(answers).map(function(k){return parseInt(k,10)+1;});var lastAnswered=answeredIndexes.length?Math.max.apply(null,answeredIndexes):0;
      fd.append('answers',JSON.stringify(answers));fd.append('current_step',step);fd.append('last_question',lastAnswered);fd.append('event',event||'progress');fd.append('email',email);
      fd.append('consent',consent?'1':'0');fd.append('complete',event==='complete'?'1':'0');
      return fetch(cfg.ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();});
    }
    function brand(){return '<div class="ddx-brand"><span class="ddx-brand-mark"></span><span>Digitálny detox</span><span aria-hidden="true">·</span><span>Test digitálnej záťaže</span></div>';}
    function progress(){
      var html='<div class="ddx-step-row"><span>Váš pokrok</span><strong>Otázka '+(step+1)+' z '+total+'</strong></div><div class="ddx-progress" role="progressbar" aria-valuemin="0" aria-valuemax="'+total+'" aria-valuenow="'+(step+1)+'" aria-label="Priebeh testu">';
      for(var i=0;i<total;i++)html+='<span class="'+(i<=step?'is-done':'')+'"></span>';
      return html+'</div>';
    }
    function goNext(){
      if(answers[step]===undefined)return;
      if(step<total-1){step++;renderQuestion();post('progress').catch(function(){});}
      else renderEmail();
    }
    function renderQuestion(){
      if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}
      var q=cfg.questions[step],selected=answers[step];
      var html=brand()+progress()+'<p class="ddx-kicker">Zamyslite sa nad svojimi návykmi</p><h2>'+esc(q.text)+'</h2><div class="ddx-options">';
      q.options.forEach(function(o){html+='<button type="button" class="ddx-option '+(selected===o.label?'is-selected':'')+'" data-answer="'+esc(o.label)+'" aria-pressed="'+(selected===o.label?'true':'false')+'"><span class="ddx-radio" aria-hidden="true"></span><span>'+esc(o.label)+'</span></button>';});
      html+='</div><div class="ddx-actions">'+(step>0?'<button type="button" class="ddx-btn ddx-btn-secondary" data-back>Späť</button>':'<span></span>')+'<button type="button" class="ddx-btn ddx-btn-primary" data-next '+(selected===undefined?'disabled':'')+'>Pokračovať</button></div><div class="ddx-hint" aria-live="polite">Vyberte odpoveď. Na ďalšiu otázku prejdete automaticky.</div><div class="ddx-error" role="alert"></div>';
      root.innerHTML=html;
      root.querySelectorAll('[data-answer]').forEach(function(btn){btn.addEventListener('click',function(){
        if(busy)return;
        if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}
        answers[step]=btn.getAttribute('data-answer');
        root.querySelectorAll('[data-answer]').forEach(function(option){var chosen=option===btn;option.classList.toggle('is-selected',chosen);option.setAttribute('aria-pressed',chosen?'true':'false');});
        var next=root.querySelector('[data-next]');if(next)next.disabled=false;
        var hint=root.querySelector('.ddx-hint');if(hint)hint.textContent='Odpoveď uložená';
        post('answer').catch(function(){});
        advanceTimer=setTimeout(goNext,360);
      });});
      var next=root.querySelector('[data-next]');
      next.addEventListener('click',function(){if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}goNext();});
      var back=root.querySelector('[data-back]');
      if(back)back.addEventListener('click',function(){if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}step=Math.max(0,step-1);renderQuestion();});
    }
    function renderEmail(){
      if(advanceTimer){clearTimeout(advanceTimer);advanceTimer=null;}
      root.innerHTML=brand()+'<p class="ddx-kicker">Test je dokončený</p>'+progress()+'<h2>'+esc(cfg.strings.emailTitle)+'</h2><label for="ddx-email">'+esc(cfg.emailLabel)+'</label><input id="ddx-email" class="ddx-field" type="email" autocomplete="email" placeholder="'+esc(cfg.emailDescription)+'" value="'+esc(email)+'"><div class="ddx-terms">'+esc(cfg.terms)+'</div><label class="ddx-consent"><input type="checkbox" id="ddx-consent" '+(consent?'checked':'')+'><span>'+esc(cfg.consentLabel)+(cfg.privacyUrl?' <a href="'+esc(cfg.privacyUrl)+'" target="_blank" rel="noopener">Zásady ochrany osobných údajov</a>':'')+'</span></label><div class="ddx-actions"><button type="button" class="ddx-btn ddx-btn-secondary" data-back>Späť</button><button type="button" class="ddx-btn ddx-btn-primary" data-submit>'+esc(cfg.strings.finish)+'</button></div><div class="ddx-error" role="alert"></div>';
      root.querySelector('[data-back]').addEventListener('click',function(){step=total-1;renderQuestion();});
      root.querySelector('#ddx-email').addEventListener('change',function(){email=this.value.trim();post('progress').catch(function(){});});
      root.querySelector('#ddx-consent').addEventListener('change',function(){consent=this.checked;post('progress').catch(function(){});});
      root.querySelector('[data-submit]').addEventListener('click',function(){
        if(busy)return;
        email=root.querySelector('#ddx-email').value.trim();consent=root.querySelector('#ddx-consent').checked;
        var err=root.querySelector('.ddx-error');
        if(!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){err.textContent=cfg.strings.invalidEmail;return;}
        if(!consent){err.textContent=cfg.strings.consentRequired;return;}
        busy=true;err.textContent=cfg.strings.sending;
        post('complete').then(function(res){busy=false;if(!res.success){err.textContent=(res.data&&res.data.message)||cfg.strings.error;return;}renderResult(res.data);}).catch(function(){busy=false;err.textContent=cfg.strings.error;});
      });
    }
    function renderList(items){
      if(!Array.isArray(items)||!items.length)return '';
      return '<ul>'+items.map(function(item){return '<li>'+esc(item)+'</li>';}).join('')+'</ul>';
    }
    function renderResult(data){
      var r=data.result||{},score=Math.max(0,Math.min(32,parseInt(data.score,10)||0)),pct=Math.round(score/32*100);
      var key=data.result_key||'medium',tone=key==='low'?'low':(key==='high'?'high':'medium');
      var scale='<div class="ddx-score-scale" aria-label="Skóre '+score+' z 32 bodov"><div class="ddx-scale-track"><span class="ddx-scale-fill ddx-tone-'+tone+'" style="width:'+pct+'%"></span><span class="ddx-scale-marker" style="left:'+pct+'%"></span></div><div class="ddx-scale-labels"><span>0</span><span>9</span><span>20</span><span>32 bodov</span></div></div>';
      var html=brand()+'<section class="ddx-result" aria-labelledby="ddx-result-title"><div class="ddx-result-topline"><span class="ddx-result-eyebrow">VYHODNOTENIE TESTU</span><span class="ddx-result-chip ddx-chip-'+tone+'">'+esc(r.title||'Výsledok testu')+'</span></div>';
      html+='<div class="ddx-result-hero"><div class="ddx-result-copy"><p class="ddx-result-label">Váš digitálny profil</p><h2 id="ddx-result-title">'+esc(r.lead||r.subtitle||r.title||'Výsledok testu')+'</h2><p class="ddx-result-intro">'+esc(r.intro||'Pozrite sa, čo vaše skóre naznačuje o vašich digitálnych návykoch.')+'</p></div><div class="ddx-score-circle" role="img" aria-label="'+score+' z 32 bodov"><span class="ddx-score-number">'+score+'</span><span class="ddx-score-denom">z 32 bodov</span></div></div>';
      html+=scale;
      if(r.detail)html+='<div class="ddx-result-detail"><span class="ddx-detail-icon" aria-hidden="true">i</span><p>'+esc(r.detail)+'</p></div>';
      if(Array.isArray(r.points)&&r.points.length){html+='<div class="ddx-result-section"><h3>'+(key==='low'?'Vaše silné stránky':'Čomu venovať pozornosť')+'</h3><ul class="ddx-result-points">'+r.points.map(function(item){return '<li><span class="ddx-point-mark" aria-hidden="true">'+(key==='low'?'✓':'•')+'</span><span>'+esc(item)+'</span></li>';}).join('')+'</ul></div>';}
      if(r.profile_title){html+='<div class="ddx-profile"><div class="ddx-profile-heading"><span class="ddx-profile-icon" aria-hidden="true">✦</span><div><span class="ddx-profile-overline">CHCETE ÍSŤ VIAC DO HĹBKY?</span><h3>Objavte svoj digitálny profil</h3></div></div><p class="ddx-profile-description">Získajte podrobnejšiu analýzu svojich návykov a konkrétne odporúčania pre väčšiu digitálnu rovnováhu.</p>'+renderList(r.profile_points)+'<a class="ddx-cta" href="'+esc(r.url||'#')+'">Zobraziť detailný digitálny profil <span aria-hidden="true"> →</span></a></div>';}
      html+='<p class="ddx-disclaimer">Výsledok je orientačný a slúži na informačné účely. Nenahrádza odborné ani zdravotné posúdenie.</p></section>';
      root.innerHTML=html;
      try{localStorage.removeItem(sidKey);}catch(e){}
    }
    renderQuestion();post('view').catch(function(){});
  });
})();

<?php
/**
 * Plugin Name: Digitálny Detox – Test digitálnej záťaže
 * Description: Vlastný interaktívny test digitálnej záťaže s bodovaním, ukladaním priebehu a administráciou.
 * Version: 0.4.0
 * Author: DigitalnyDetox.sk
 * Text Domain: digitalnydetox-test
 */

if (!defined('ABSPATH')) exit;

class DDX_Test_Plugin {
    const VERSION = '0.4.0';
    const DB_VERSION = '3';
    const OPTION = 'ddx_test_config';
    const NONCE_ACTION = 'ddx_test_public';
    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_shortcode('digitalny_detox_test', array($this, 'shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('wp_ajax_ddx_save_progress', array($this, 'ajax_save_progress'));
        add_action('wp_ajax_nopriv_ddx_save_progress', array($this, 'ajax_save_progress'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_ddx_export_csv', array($this, 'export_csv'));
        add_action('admin_post_ddx_import_formsapp', array($this, 'import_formsapp'));
        add_action('admin_post_ddx_test_notification', array($this, 'send_test_notification'));
        add_action('admin_init', array($this, 'maybe_upgrade')); 
    }

    public function table() {
        global $wpdb;
        return $wpdb->prefix . 'ddx_test_entries';
    }

    public function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$this->table()} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            source varchar(30) NOT NULL DEFAULT 'plugin',
            external_id varchar(100) DEFAULT NULL,
            email varchar(190) DEFAULT NULL,
            answers longtext NOT NULL,
            current_step int(11) NOT NULL DEFAULT 0,
            score int(11) NOT NULL DEFAULT 0,
            result_key varchar(30) DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'in_progress',
            consent tinyint(1) NOT NULL DEFAULT 0,
            started_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            completed_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_id (session_id),
            KEY status (status),
            KEY updated_at (updated_at),
            UNIQUE KEY external_id (external_id)
        ) $charset;";
        dbDelta($sql);
        if (!get_option(self::OPTION)) add_option(self::OPTION, $this->default_config());
        update_option('ddx_test_db_version', self::DB_VERSION);
    }

    public function maybe_upgrade() {
        if (get_option('ddx_test_db_version') !== self::DB_VERSION) {
            $this->activate();
        }
    }

    private function default_config() {
        $questions = array(
            array('text'=>'Kontrolujem si správy/aktivity na mobile hneď po zobudení?', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Telefón mám stále po ruke, mám ho aj pri posteli.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Cítim nutkanie skontrolovať si mobil aj bez toho, aby mi prišla notifikácia.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Odkladám úlohy a povinnosti na úkor času pred obrazovkou.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Nedokážem sa sústrediť pri práci/štúdiu kvôli online vyrušeniam.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Chodievam spať neskôr, pretože som dlhšie za počítačom alebo na mobile.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Mobil používam aj pri prechádzke alebo jazde autom.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0))),
            array('text'=>'Jedávam s mobilom v ruke alebo pred televízorom, či notebookom.', 'options'=>array(array('label'=>'Áno','points'=>1),array('label'=>'Nie','points'=>0))),
            array('text'=>'Keď som bez mobilu, bývam nervózny.', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Pred okolím ukrývam moje aktivity na mobile.', 'options'=>array(array('label'=>'Áno','points'=>1),array('label'=>'Nie','points'=>0))),
            array('text'=>'Denne trávim na sociálnych sieťach viac času, než by som chcel.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0))),
            array('text'=>'Cítim sa zle, keď mi niečo unikne (novinky/správy).', 'options'=>array(array('label'=>'Nikdy','points'=>0),array('label'=>'Zriedkavo','points'=>1),array('label'=>'Často','points'=>2),array('label'=>'Veľmi často','points'=>3))),
            array('text'=>'Myslím si, že trávim na mobile viac času, než je pre mňa zdravé.', 'options'=>array(array('label'=>'Áno','points'=>2),array('label'=>'Nie','points'=>0)))
        );
        $common = "Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:\n• ktoré oblasti vás najviac ovplyvňujú\n• ako technológie ovplyvňujú jednotlivé oblasti vášho života\n• ako je na tom vaša digitálna rovnováha\n• vaše slabé miesto\n• čo konkrétne s tým môžete urobiť";
        return array(
            'questions'=>$questions,
            'results'=>array(
                'low'=>array('min'=>0,'max'=>9,'title'=>'Nízke riziko','subtitle'=>'Máte digitálny svet prevažne pod kontrolou','lead'=>'Máte digitálny svet prevažne pod kontrolou','intro'=>'Skvelé, máte dobré digitálne návyky a váš vzťah k technológiám je celkom zdravý!','points'=>array('viete sa venovať tomu, čo je pre vás dôležité','máte zdravé limity a rovnováhu','dokážete odložiť mobil bez stresu'),'detail'=>'Zdá sa, že digitálne technológie máte pod kontrolou a využívate ich prevažne užitočným spôsobom. Digitálny svet vám slúži – nie naopak.','profile_title'=>'Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:','profile_points'=>array('ktoré oblasti vás najviac ovplyvňujú','ako technológie ovplyvňujú jednotlivé oblasti vášho života','ako je na tom vaša digitálna rovnováha','vaše slabé miesto','čo konkrétne s tým môžete urobiť'),'body'=>"Skvelé, máte dobré digitálne návyky a váš vzťah k technológiám je celkom zdravý!\nZdá sa, že digitálne technológie máte pod kontrolou a využívate ich prevažne užitočným spôsobom. Digitálny svet vám slúži - nie naopak.\n\nSilné stránky:\n• viete sa venovať tomu, čo je pre vás dôležité\n• máte zdravé limity a rovnováhu\n• dokážete odložiť mobil bez stresu\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-nizke-riziko/'),
                'medium'=>array('min'=>10,'max'=>20,'title'=>'Zvýšené riziko','subtitle'=>'Technológie začínajú ovplyvňovať vaše zdravie, pozornosť alebo vzťahy','lead'=>'Technológie začínajú ovplyvňovať vaše zdravie, pozornosť alebo vzťahy','intro'=>'Objavujú sa u vás digitálne návyky, ktoré vám môžu škodiť – brať energiu, sústredenie aj čas. Máte oblasti, kde digitálny svet preberá kontrolu. Ide o varovný signál, ktorý stojí za to riešiť, aby sa situácia nezhoršovala. Nie je to nič dramatické – no ak nič nezmeníte, môže sa to zhoršovať. Našťastie to viete ešte otočiť pomerne jednoducho.','points'=>array('príliš veľa času online bez toho, aby ste si to uvedomovali','slabšia koncentrácia kvôli vyrušeniam','spánok a energia idú dolu','menej prítomnosti v osobnom živote'),'detail'=>'','profile_title'=>'Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:','profile_points'=>array('ktoré oblasti vás najviac ovplyvňujú','ako technológie ovplyvňujú jednotlivé oblasti vášho života','ako je na tom vaša digitálna rovnováha','vaše slabé miesto','čo konkrétne s tým môžete urobiť'),'body'=>"⚠️ Objavujú sa u vás digitálne návyky, ktoré vám môžu škodiť - brať energiu, sústredenie aj čas. Máte oblasti, kde digitálny svet preberá kontrolu. Ide o varovný signál, ktorý stojí za to riešiť, aby sa situácia nezhoršila. Nie je to nič dramatické - no ak nič nezmeníte, môže sa to zhoršovať. Našťastie to viete ešte otočiť pomerne jednoducho.\n\nČo vám môže spôsobovať problémy:\n• príliš veľa času online bez toho, aby ste si to uvedomovali\n• slabšia koncentrácia kvôli vyrušeniam\n• spánok a energia idú dolu\n• menej prítomnosti v osobnom živote\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-stredne-riziko/'),
                'high'=>array('min'=>21,'max'=>32,'title'=>'Vysoké riziko','subtitle'=>'Váš digitálny život prerastá do offline sveta','lead'=>'Váš digitálny život prerastá do offline sveta','intro'=>'Váš výsledok naznačuje, že vaša úroveň digitálneho stresu a návykov je vysoká a technológie majú pravdepodobne už pomerne výrazný dopad na vašu psychiku, výkon, spánok alebo vzťahy.','points'=>array('silné nutkanie byť stále online','ponocovanie a vyčerpanie','konflikty alebo izolácia','únik pred stresom cez obrazovku'),'detail'=>'Váš vzťah k technológiám si vyžaduje zásadnejšiu zmenu.','profile_title'=>'Získajte detailný digitálny profil s kompletnou analýzou a odporúčaniami na zníženie záťaže, v ktorom uvidíte:','profile_points'=>array('ktoré oblasti vás najviac ovplyvňujú','ako technológie ovplyvňujú jednotlivé oblasti vášho života','ako je na tom vaša digitálna rovnováha','vaše slabé miesto','čo konkrétne s tým môžete urobiť'),'body'=>"🚨 Váš výsledok naznačuje, že vaša úroveň digitálneho stresu a návykov je vysoká a technológie majú pravdepodobne už pomerne výrazný dopad na vašu psychiku, výkon, spánok alebo vzťahy.\nVáš vzťah k technológiám si vyžaduje zásadnejšiu zmenu.\n\nNajčastejšie sa to prejavuje ako:\n• silné nutkanie byť stále online\n• ponocovanie a vyčerpanie\n• konflikty alebo izolácia\n• únik pred stresom cez obrazovku\n\n".$common,'url'=>'https://www.digitalnydetox.sk/obchod/detailny-digitalny-profil-vysoke-riziko/')
            ),
            'email_label'=>'E-mail','email_description'=>'zadajte vašu e-mailovú adresu',
            'consent_label'=>'Súhlasím s podmienkami používania.',
            'terms'=>'Tento test je bezplatný a slúži výlučne na informatívne a orientačné účely. Vyplnením a odoslaním testu nevzniká návštevníkovi žiadna povinnosť úhrady ani záväzok k nákupu.\n\nNa základe výsledku testu môže byť návštevníkovi dobrovoľne ponúknutá možnosť presmerovania na webovú stránku www.digitalnydetox.sk, kde je možné zakúpiť si detailnejší alebo rozšírený výsledok testu alebo súvisiace služby. Nákup prebieha výhradne na tejto webovej stránke a riadi sa jej samostatnými obchodnými podmienkami.\n\nÚdaje uvedené v teste sú spracované v súlade s platnými právnymi predpismi o ochrane osobných údajov a výlučne za účelom vyhodnotenia testu a zobrazenia výsledku. Prevádzkovateľ testu nezodpovedá za rozhodnutia návštevníka prijaté na základe orientačného výsledku testu.\n\nPoužívaním tohto testu potvrdzujete, že ste sa s týmito podmienkami oboznámili a súhlasíte s nimi.',
            'privacy_url'=>'', 'notification_enabled'=>1, 'notification_email'=>get_option('admin_email'), 'primary_color'=>'#FEBF00','background_color'=>'#FFFFFF','font'=>'Poppins'
        );
    }

    public function config() {
        $saved = get_option(self::OPTION, array());
        $defaults = $this->default_config();
        $cfg = wp_parse_args($saved, $defaults);
        foreach (array('low','medium','high') as $key) {
            if (isset($defaults['results'][$key])) {
                $cfg['results'][$key] = wp_parse_args(isset($cfg['results'][$key]) ? $cfg['results'][$key] : array(), $defaults['results'][$key]);
            }
        }
        return $cfg;
    }

    public function register_assets() {
        wp_register_style('ddx-test', plugins_url('assets/test.css', __FILE__), array(), self::VERSION);
        wp_register_script('ddx-test', plugins_url('assets/test.js', __FILE__), array(), self::VERSION, true);
    }

    public function shortcode() {
        $cfg = $this->config();
        if (empty($cfg['questions']) || !is_array($cfg['questions'])) return '<p>Test momentálne nie je dostupný.</p>';
        wp_enqueue_style('ddx-test');
        wp_enqueue_script('ddx-test');
        wp_localize_script('ddx-test', 'DDXTest', array(
            'ajaxUrl'=>admin_url('admin-ajax.php'), 'nonce'=>wp_create_nonce(self::NONCE_ACTION),
            'questions'=>$cfg['questions'], 'emailLabel'=>$cfg['email_label'], 'emailDescription'=>$cfg['email_description'],
            'consentLabel'=>$cfg['consent_label'], 'terms'=>$cfg['terms'], 'privacyUrl'=>$cfg['privacy_url'],
            'primaryColor'=>$cfg['primary_color'], 'backgroundColor'=>$cfg['background_color'], 'font'=>$cfg['font'],
            'strings'=>array('next'=>'Pokračovať','back'=>'Späť','finish'=>'Vyhodnotiť test','emailTitle'=>'Kam vám môžeme poslať výsledok?','required'=>'Vyplňte, prosím, túto položku.','invalidEmail'=>'Zadajte platnú e-mailovú adresu.','consentRequired'=>'Pre pokračovanie potvrďte súhlas s podmienkami.','sending'=>'Vyhodnocujem test…','error'=>'Údaje sa nepodarilo uložiť. Skúste to znova.')
        ));
        return '<div id="ddx-test-app" class="ddx-test-app" aria-live="polite"><div class="ddx-loading">Načítavam test…</div></div>';
    }

    public function ajax_save_progress() {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        global $wpdb;
        $session = isset($_POST['session_id']) ? sanitize_text_field(wp_unslash($_POST['session_id'])) : '';
        if (!preg_match('/^[a-f0-9-]{32,36}$/i', $session)) wp_send_json_error(array('message'=>'Neplatná relácia.'), 400);
        $cfg = $this->config();
        $answers_raw = isset($_POST['answers']) ? wp_unslash($_POST['answers']) : '{}';
        $answers = json_decode($answers_raw, true);
        if (!is_array($answers)) $answers = array();
        $clean_answers = array(); $score = 0;
        foreach ($answers as $key=>$value) {
            $index = absint($key);
            if (!isset($cfg['questions'][$index])) continue;
            $points = null;
            foreach ($cfg['questions'][$index]['options'] as $option) {
                if (isset($option['label']) && (string)$option['label'] === (string)$value) { $points = intval($option['points']); break; }
            }
            if ($points !== null) { $clean_answers[$index] = sanitize_text_field($value); $score += $points; }
        }
        $step = isset($_POST['current_step']) ? min(count($cfg['questions']), max(0, absint($_POST['current_step']))) : count($clean_answers);
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        if ($email && !is_email($email)) wp_send_json_error(array('message'=>'Neplatná e-mailová adresa.'), 400);
        $consent = !empty($_POST['consent']) ? 1 : 0;
        $complete = !empty($_POST['complete']) && $email && $consent && count($clean_answers) === count($cfg['questions']);
        $result_key = $this->result_key($score, $cfg);
        $now = current_time('mysql');
        $table = $this->table();
        $existing_row = $wpdb->get_row($wpdb->prepare("SELECT id,status FROM $table WHERE session_id=%s", $session));
        $was_completed = ($existing_row && $existing_row->status === 'completed');
        $data = array('email'=>$email ?: null, 'answers'=>wp_json_encode($clean_answers), 'current_step'=>$step, 'score'=>$score, 'result_key'=>$complete ? $result_key : null, 'status'=>$complete ? 'completed' : 'in_progress', 'consent'=>$consent, 'updated_at'=>$now, 'completed_at'=>$complete ? $now : null);
        if ($existing_row) $wpdb->update($table, $data, array('session_id'=>$session));
        else { $data['session_id']=$session; $data['started_at']=$now; $wpdb->insert($table, $data); }
        if ($wpdb->last_error) wp_send_json_error(array('message'=>'Databázová chyba.'), 500);
        if ($complete) {
            if (!$was_completed) {
                $this->send_completion_notification(array('email'=>$email, 'score'=>$score, 'result_key'=>$result_key, 'completed_at'=>$now, 'session_id'=>$session), $cfg);
            }
            $r = $cfg['results'][$result_key];
            wp_send_json_success(array('complete'=>true,'score'=>$score,'result_key'=>$result_key,'result'=>$r));
        }
        wp_send_json_success(array('complete'=>false,'saved'=>true));
    }

    private function result_key($score, $cfg) {
        foreach (array('low','medium','high') as $key) {
            if (isset($cfg['results'][$key]) && $score >= intval($cfg['results'][$key]['min']) && $score <= intval($cfg['results'][$key]['max'])) return $key;
        }
        return 'low';
    }

    public function admin_menu() {
        add_menu_page('Digitálny test','Digitálny test','manage_options','ddx-test',array($this,'admin_entries'),'dashicons-clipboard',56);
        add_submenu_page('ddx-test','Výsledky testov','Výsledky testov','manage_options','ddx-test',array($this,'admin_entries'));
        add_submenu_page('ddx-test','Nastavenia testu','Nastavenia testu','manage_options','ddx-test-settings',array($this,'admin_settings'));
    }

    public function register_settings() {
        register_setting('ddx_test_group', self::OPTION, array($this,'sanitize_config'));
    }

    public function sanitize_config($input) {
        $defaults = $this->default_config();
        if (!is_array($input)) return $defaults;
        $out = $defaults;
        foreach (array('email_label','email_description','consent_label','terms','privacy_url','primary_color','background_color','font') as $key) {
            if (isset($input[$key])) $out[$key] = ($key === 'privacy_url') ? esc_url_raw($input[$key]) : sanitize_textarea_field($input[$key]);
        }
        $out['notification_enabled'] = !empty($input['notification_enabled']) ? 1 : 0;
        $recipient = isset($input['notification_email']) ? sanitize_email($input['notification_email']) : get_option('admin_email');
        $out['notification_email'] = is_email($recipient) ? $recipient : get_option('admin_email');
        foreach (array('questions','results') as $key) {
            if (isset($input[$key]) && is_string($input[$key])) {
                $decoded = json_decode(wp_unslash($input[$key]), true);
                if (is_array($decoded)) $out[$key] = $decoded;
            } elseif (isset($input[$key]) && is_array($input[$key])) $out[$key] = $input[$key];
        }
        return $out;
    }

    public function admin_settings() {
        if (!current_user_can('manage_options')) return;
        $cfg = $this->config();
        $qjson = wp_json_encode($cfg['questions'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $rjson = wp_json_encode($cfg['results'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        echo '<div class="wrap"><h1>Nastavenia digitálneho testu</h1><p>Otázky, odpovede a bodovanie sa dajú upravovať v JSON editore. Pred úpravou odporúčame exportovať nastavenia alebo si skopírovať pôvodný obsah.</p><form method="post" action="options.php">';
        settings_fields('ddx_test_group');
        echo '<h2>Otázky a odpovede</h2><textarea name="'.esc_attr(self::OPTION).'[questions]" rows="22" style="width:100%;font-family:monospace">'.esc_textarea($qjson).'</textarea>';
        echo '<h2>Výsledkové kategórie</h2><textarea name="'.esc_attr(self::OPTION).'[results]" rows="22" style="width:100%;font-family:monospace">'.esc_textarea($rjson).'</textarea>';
        echo '<h2>E-mailové notifikácie</h2><table class="form-table"><tr><th>Notifikácie po dokončení testu</th><td><label><input type="checkbox" name="'.esc_attr(self::OPTION).'[notification_enabled]" value="1" '.checked(!empty($cfg['notification_enabled']), true, false).' /> Posielať e-mail po každom dokončenom teste</label></td></tr><tr><th>Príjemca notifikácií</th><td><input type="email" class="regular-text" name="'.esc_attr(self::OPTION).'[notification_email]" value="'.esc_attr(!empty($cfg['notification_email'])?$cfg['notification_email']:get_option('admin_email')).'" required /><p class="description">Predvolená adresa je e-mail administrátora WordPressu.</p></td></tr></table>';
        if (isset($_GET['ddx_mail'])) { $mail_msg = $_GET['ddx_mail']==='sent' ? 'Skúšobný e-mail bol odoslaný.' : 'E-mail sa nepodarilo odoslať. Skontrolujte nastavenie odosielania pošty na hostingu.'; echo '<div class="notice '.($_GET['ddx_mail']==='sent'?'notice-success':'notice-error').'"><p>'.esc_html($mail_msg).'</p></div>'; }
        echo '<h2>Vzhľad a texty</h2><table class="form-table"><tr><th>Primárna farba</th><td><input name="'.esc_attr(self::OPTION).'[primary_color]" value="'.esc_attr($cfg['primary_color']).'" /></td></tr><tr><th>Farba pozadia</th><td><input name="'.esc_attr(self::OPTION).'[background_color]" value="'.esc_attr($cfg['background_color']).'" /></td></tr><tr><th>Font</th><td><input name="'.esc_attr(self::OPTION).'[font]" value="'.esc_attr($cfg['font']).'" /></td></tr><tr><th>Označenie e-mailu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[email_label]" value="'.esc_attr($cfg['email_label']).'" /></td></tr><tr><th>Popis e-mailu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[email_description]" value="'.esc_attr($cfg['email_description']).'" /></td></tr><tr><th>Text súhlasu</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[consent_label]" value="'.esc_attr($cfg['consent_label']).'" /></td></tr><tr><th>URL zásad ochrany súkromia</th><td><input class="regular-text" name="'.esc_attr(self::OPTION).'[privacy_url]" value="'.esc_attr($cfg['privacy_url']).'" /></td></tr><tr><th>Podmienky používania</th><td><textarea name="'.esc_attr(self::OPTION).'[terms]" rows="8" class="large-text">'.esc_textarea($cfg['terms']).'</textarea></td></tr></table>';
        submit_button('Uložiť nastavenia'); echo '</form>';
        echo '<h2>Test odosielania</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        echo '<input type="hidden" name="action" value="ddx_test_notification">';
        wp_nonce_field('ddx_test_notification');
        submit_button('Odoslať skúšobný e-mail', 'secondary', 'submit', false);
        echo '</form><p><strong>Shortcode:</strong> <code>[digitalny_detox_test]</code></p></div>';
    }

    private function send_completion_notification($entry, $cfg = null) {
        $cfg = $cfg ? $cfg : $this->config();
        if (empty($cfg['notification_enabled'])) return false;
        $to = !empty($cfg['notification_email']) ? sanitize_email($cfg['notification_email']) : get_option('admin_email');
        if (!is_email($to)) return false;
        $result_title = isset($cfg['results'][$entry['result_key']]['title']) ? $cfg['results'][$entry['result_key']]['title'] : $entry['result_key'];
        $subject = 'Nový dokončený test digitálnej záťaže';
        $admin_url = admin_url('admin.php?page=ddx-test');
        $message = "Bol dokončený nový test digitálnej záťaže.\n\n";
        $message .= 'Dátum a čas: ' . $entry['completed_at'] . "\n";
        $message .= 'E-mail účastníka: ' . ($entry['email'] ? $entry['email'] : 'Neuvedený') . "\n";
        $message .= 'Skóre: ' . intval($entry['score']) . " / 32\n";
        $message .= 'Výsledok: ' . $result_title . "\n\n";
        $message .= "Záznamy a odpovede nájdete v administrácii WordPressu:\n" . $admin_url . "\n";
        return wp_mail($to, $subject, $message, array('Content-Type: text/plain; charset=UTF-8'));
    }

    public function send_test_notification() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        check_admin_referer('ddx_test_notification');
        $cfg = $this->config();
        $to = !empty($cfg['notification_email']) ? sanitize_email($cfg['notification_email']) : get_option('admin_email');
        $sent = is_email($to) ? wp_mail($to, 'Skúšobná notifikácia – Digitálny Detox', "Toto je skúšobný e-mail z pluginu Digitálny Detox.\n\nAk ste ho dostali, odosielanie e-mailových notifikácií je funkčné.", array('Content-Type: text/plain; charset=UTF-8')) : false;
        $url = add_query_arg(array('page'=>'ddx-test-settings','ddx_mail'=>$sent?'sent':'failed'), admin_url('admin.php'));
        wp_safe_redirect($url); exit;
    }

    public function admin_entries() {
        if (!current_user_can('manage_options')) return;
        global $wpdb; $table=$this->table();
        $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY started_at DESC LIMIT 500");
        $total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
        $completed=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status IN ('completed','imported_complete')");
        $started=$total; $abandoned=$total-$completed;
        echo '<div class="wrap"><h1>Výsledky a štatistiky testu</h1><p><strong>Začaté relácie:</strong> '.esc_html($started).' &nbsp; <strong>Dokončené:</strong> '.esc_html($completed).' &nbsp; <strong>Nedokončené:</strong> '.esc_html($abandoned).' &nbsp; <strong>Miera dokončenia:</strong> '.esc_html($started ? round($completed/$started*100,1) : 0).'%</p>';
        echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin-post.php?action=ddx_export_csv')).'">Exportovať CSV</a></p>';
        echo '<h2>Import historických výsledkov z forms.app</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data">';
        echo '<input type="hidden" name="action" value="ddx_import_formsapp">';
        wp_nonce_field('ddx_import_formsapp');
        echo '<input type="file" name="formsapp_csv" accept=".csv,text/csv" required> ';
        submit_button('Importovať CSV', 'secondary', 'submit', false);
        echo '<p class="description">Importuje CSV export z forms.app. Už importované Submission ID sa preskočia. Pôvodné skóre sa nemení; prázdne skóre zostane nevyhodnotené.</p></form>';
        if (isset($_GET['ddx_imported'])) echo '<div class="notice notice-success"><p>Import dokončený. Importované: '.intval($_GET['ddx_imported']).', preskočené: '.intval($_GET['ddx_skipped']).', chyby: '.intval($_GET['ddx_errors']).'.</p></div>';
        echo '<table class="widefat striped"><thead><tr><th>Dátum začatia</th><th>E-mail</th><th>Stav</th><th>Posledný krok</th><th>Skóre</th><th>Výsledok</th><th>Zdroj</th><th>Posledná aktivita</th></tr></thead><tbody>';
        if ($rows) foreach ($rows as $row) {
            $answers=json_decode($row->answers,true); if (!is_array($answers)) $answers=array();
            $status=$row->status==='completed'?'Dokončený':($row->status==='imported_incomplete'?'Importovaný – neúplný':(strtotime($row->updated_at) < time()-1800 ? 'Opustený / neaktívny':'Rozpracovaný'));
            if ($row->status==='imported_complete') $status='Importovaný – dokončený';
            $step = count($answers) . ' / 13';
            $score_display = ($row->score >= 0 && in_array($row->status, array('completed','imported_complete','imported_incomplete'), true)) ? $row->score : '—';
            $result_label = ($row->result_key && isset($this->config()['results'][$row->result_key]['title'])) ? $this->config()['results'][$row->result_key]['title'] : '—';
            echo '<tr><td>'.esc_html($row->started_at).'</td><td>'.esc_html($row->email ?: '—').'</td><td>'.esc_html($status).'</td><td>'.esc_html($step).'</td><td>'.esc_html($score_display).'</td><td>'.esc_html($result_label).'</td><td>'.esc_html($row->source==='formsapp'?'forms.app':'Plugin').'</td><td>'.esc_html($row->updated_at).'</td></tr>';
            if ($answers) echo '<tr><td colspan="8"><details><summary>Zobraziť odpovede</summary><ol>';  foreach ($answers as $i=>$answer) echo '<li>'.esc_html(isset($this->config()['questions'][$i]['text'])?$this->config()['questions'][$i]['text']:'Otázka').' — <strong>'.esc_html($answer).'</strong></li>'; if ($answers) echo '</ol></details></td></tr>';
        } else echo '<tr><td colspan="8">Zatiaľ neboli zaznamenané žiadne vyplnenia.</td></tr>';
        echo '</tbody></table><p class="description">Zobrazuje sa najviac 500 posledných relácií. Neaktívna relácia sa po 30 minútach bez uloženia zobrazuje ako opustená. E-mail bude dostupný iba vtedy, ak ho návštevník pred odchodom zadal.</p></div>';
    }

    public function import_formsapp() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        check_admin_referer('ddx_import_formsapp');
        if (empty($_FILES['formsapp_csv']['tmp_name']) || !is_uploaded_file($_FILES['formsapp_csv']['tmp_name'])) wp_die('CSV súbor sa nepodarilo načítať.');
        $fh = fopen($_FILES['formsapp_csv']['tmp_name'], 'r');
        if (!$fh) wp_die('CSV súbor sa nepodarilo otvoriť.');
        $headers = fgetcsv($fh, 0, ',');
        if (!$headers) { fclose($fh); wp_die('CSV súbor je prázdny.'); }
        $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', $headers[0]);
        $header_map = array_flip($headers);
        $question_headers = array(
            'Kontrolujem si správy/aktivity na mobile hneď po zobudení?',
            'Telefón mám stále po ruke, mám ho aj pri posteli.',
            'Cítim nutkanie skontrolovať si mobil aj bez toho, aby mi prišla notifikácia.',
            'Odkladám úlohy a povinnosti na úkor času pred obrazovkou.',
            'Nedokážem sa sústrediť pri práci/štúdiu kvôli online vyrušeniam.',
            'Chodievam spať neskôr, pretože som dlhšie za počítačom alebo na mobile.',
            'Mobil používam aj pri prechádzke alebo jazde autom.',
            'Jedávam s mobilom v ruke alebo pred televízorom, či notebookom.',
            'Keď som bez mobilu, bývam nervózny.',
            'Pred okolím ukrývam moje aktivity na mobile.',
            'Denne trávim na sociálnych sieťach viac času, než by som chcel.',
            'Cítim sa zle, keď mi niečo unikne (novinky/správy).',
            'Myslím si, že trávim na mobile viac času, než je pre mňa zdravé.'
        );
        $required = array_merge($question_headers, array('E-mail','Total Score','Submission Date','Submission ID'));
        foreach ($required as $col) {
            if (!array_key_exists($col, $header_map)) { fclose($fh); wp_die('CSV nemá očakávaný stĺpec: '.esc_html($col)); }
        }
        global $wpdb; $table = $this->table(); $cfg = $this->config();
        $imported = 0; $skipped = 0; $errors = 0;
        while (($row = fgetcsv($fh, 0, ',')) !== false) {
            if (count($row) < count($headers)) { $row = array_pad($row, count($headers), ''); }
            $get = function($name) use ($header_map, $row) { return isset($header_map[$name], $row[$header_map[$name]]) ? trim((string)$row[$header_map[$name]]) : ''; };
            $external_id = sanitize_text_field($get('Submission ID'));
            $email = sanitize_email($get('E-mail'));
            if (!$external_id || !$email || !is_email($email)) { $errors++; continue; }
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE external_id=%s", $external_id));
            if ($exists) { $skipped++; continue; }
            $answers = array(); $answered = 0;
            foreach ($question_headers as $i=>$question) {
                $answer = $get($question);
                if ($answer === '') continue;
                $answers[$i] = $answer; $answered++;
            }
            $score_raw = $get('Total Score');
            $score = ($score_raw !== '' && is_numeric($score_raw)) ? intval($score_raw) : -1;
            if ($score > 32 || $score < -1) { $errors++; continue; }
            $result_key = $score >= 0 ? $this->result_key($score, $cfg) : null;
            $date_raw = $get('Submission Date');
            $date = DateTime::createFromFormat('!d/m/Y, H:i:s', $date_raw);
            if (!$date) $date = DateTime::createFromFormat('!d/m/Y H:i:s', $date_raw);
            if (!$date) { $errors++; continue; }
            $created = $date->format('Y-m-d H:i:s');
            $complete = ($score >= 0 && $answered === 13);
            $session_id = 'formsapp-' . substr(hash('sha256', $external_id), 0, 48);
            $inserted = $wpdb->insert($table, array(
                'session_id'=>$session_id, 'source'=>'formsapp', 'external_id'=>$external_id,
                'email'=>$email, 'answers'=>wp_json_encode($answers), 'current_step'=>$answered,
                'score'=>$score, 'result_key'=>$result_key, 'status'=>$complete ? 'imported_complete' : 'imported_incomplete',
                'consent'=>($get('Terms & conditions') !== '' ? 1 : 0), 'started_at'=>$created,
                'updated_at'=>$created, 'completed_at'=>$complete ? $created : null
            ));
            if ($inserted) $imported++; else $errors++;
        }
        fclose($fh);
        $url = add_query_arg(array('page'=>'ddx-test','ddx_imported'=>$imported,'ddx_skipped'=>$skipped,'ddx_errors'=>$errors), admin_url('admin.php'));
        wp_safe_redirect($url); exit;
    }

    public function export_csv() {
        if (!current_user_can('manage_options')) wp_die('Nemáte oprávnenie.');
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->table()} ORDER BY started_at DESC", ARRAY_A);
        nocache_headers(); header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=digitalny-detox-test-vysledky.csv');
        $out=fopen('php://output','w'); fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out,array('session_id','source','external_id','email','status','started_at','updated_at','completed_at','current_step','score','result_key','consent','answers'),';');
        foreach ($rows as $row) fputcsv($out,array($row['session_id'],$row['source'],$row['external_id'],$row['email'],$row['status'],$row['started_at'],$row['updated_at'],$row['completed_at'],$row['current_step'],$row['score'] >= 0 ? $row['score'] : '',$row['result_key'],$row['consent'],$row['answers']),';');
        fclose($out); exit;
    }
}
DDX_Test_Plugin::instance();

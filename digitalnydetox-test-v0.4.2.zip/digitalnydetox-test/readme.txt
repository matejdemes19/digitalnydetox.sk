DIGITÁLNY DETOX – TEST DIGITÁLNEJ ZÁŤAŽE
Verzia 0.4.2 – e-mailové výsledky a evidencia newsletter súhlasov

INŠTALÁCIA / AKTUALIZÁCIA
1. Vo WordPresse otvorte Pluginy > Pridať nový plugin > Nahrať plugin.
2. Nahrajte ZIP digitalnydetox-test-v0.4.2.zip.
3. Ak WordPress oznámi, že plugin už existuje, použite možnosť nahradiť aktuálnu verziu.
4. Na testovacej stránke /test-digitalnej-zataze/ použite shortcode: [digitalny_detox_test]
5. Po aktualizácii sa databázové tabuľky automaticky rozšíria. Existujúce výsledky zostanú zachované; nový záznam o súhlase s newsletterom sa vytvorí iba pri novom dokončení testu a aktívnom zaškrtnutí políčka.

CHANGELOG
= 0.4.2 =
- Povinná e-mailová adresa na doručenie výsledku testu.
- Automatické odoslanie skóre, kategórie a stručných odporúčaní e-mailom cez WordPress wp_mail().
- Samostatný nepovinný marketingový súhlas a evidencia jeho udelenia/odvolania.
- Samostatná administrácia a export newsletterových súhlasov vrátane uloženého znenia súhlasu a odkazu na odvolanie.
- Plugin eviduje newsletterové súhlasy; samotné rozosielanie newsletterov zabezpečuje samostatná e-mailová služba.
- Automatické vymazávanie identifikovateľných záznamov testu po 12 mesiacoch.
- Evidencia odvolaných marketingových súhlasov sa uchováva 4 roky od odvolania.
- Aktualizované podmienky a názvy kategórií rizika.

POZNÁMKA K E-MAILOM
- Doručovanie výsledkov závisí od funkčného odosielania e-mailov na hostingu alebo cez nakonfigurovanú SMTP službu. Po aktualizácii treba vykonať reálny test doručenia.
- Pred ostrým nasadením nastavte v Digitálny test > Nastavenia testu URL samostatnej stránky Zásady ochrany osobných údajov.

FUNKCIE
- 13 otázok, vždy jedna otázka na obrazovke.
- Automatický prechod na ďalšiu otázku po výbere odpovede; stále je dostupné aj tlačidlo Pokračovať.
- Výraznejší kontrast pri prejdení kurzorom a jasnejšie označenie vybratej odpovede.
- Bodovanie podľa pôvodného testu, maximálne 32 bodov.
- Redizajnovaná výsledková stránka so skóre, vizuálnou stupnicou, kategóriou, vysvetlením, bodmi a výraznejšou ponukou detailného profilu.
- Priebežné ukladanie odpovedí, e-mailu a súhlasu.
- Prehľad výsledkov s možnosťou vymazať jeden alebo viac označených záznamov; k dispozícii je aj vymazanie všetkých záznamov.
- Insights: zobrazenia, začaté a dokončené testy, miera dokončenia, priemerný čas a vývoj v čase.
- Filtrovanie analytiky podľa obdobia (7, 30, 90 dní alebo celé obdobie) a typu zariadenia.
- Zariadenia, operačné systémy, prehliadače, krajiny, regióny a mestá (ak Cloudflare posiela príslušné hlavičky).
- Statistics: rozdelenie odpovedí pri každej otázke.
- Drop-off analysis: počet návštevníkov, ktorí odpovedali na jednotlivé otázky, a miesta odchodov.
- CSV export vrátane analytických polí.
- Import historických výsledkov z CSV exportu forms.app.
- Duplicitné Submission ID sa pri opakovanom importe preskočia.
- Historické skóre sa zachováva; ak v exporte chýba, záznam ostane bez skóre a je označený ako neúplný.
- Historické záznamy sú označené zdrojom forms.app a nemiešajú sa s novými vyplneniami.

IMPORT FORMS.APP
1. V administrácii WordPress otvorte Digitálny test > Výsledky testov.
2. V sekcii Import historických výsledkov z forms.app vyberte CSV súbor. Ak máte export v ZIP archíve, najprv ho rozbaľte a vyberte CSV súbor.
3. Kliknite na Importovať CSV. Po importe sa zobrazí počet importovaných, preskočených a chybných riadkov.
4. Opätovný import toho istého súboru je bezpečný: už existujúce Submission ID sa preskočia.

CLOUDFLARE – LOKALITY
- Krajina sa získava z hlavičky CF-IPCountry. V Cloudflare pre doménu zapnite Network > IP Geolocation. Táto funkcia je dostupná aj vo Free pláne.
- Pre mesto a región zapnite Rules > Transform Rules > Managed Transforms > Add visitor location headers. Cloudflare potom posiela hlavičky CF-IPCity a CF-Region. Údaje o polohe sú približné podľa IP adresy, nie presná poloha.
- Plugin neukladá IP adresu. Ak hlavičky nie sú dostupné, príslušné polia zostanú prázdne.

DÔLEŽITÉ
- Najskôr otestujte aktualizáciu na /test-digitalnej-zataze/ a nevypínajte ani nemažte pôvodné dáta.
- E-mail sa zbiera až na poslednom kroku. Ak návštevník opustí test skôr, jeho e-mail nebude známy.
- Neaktívna relácia sa po 30 minútach bez uloženia zobrazuje ako opustená.
- Importované skóre sa neprepočítava. Kategória sa odvodí podľa aktuálnych hraníc: 0–9 nízke, 10–20 zvýšené, 21–32 vysoké riziko.
- V dodanom exporte je 19 úplných záznamov a 3 neúplné: dva bez skóre (jeden z nich má všetkých 13 odpovedí) a jeden so skóre 13, ale s chýbajúcou odpoveďou na otázku 2. Chýbajúce údaje sa nedopĺňajú; existujúce skóre sa zachová.
- Pred ostrým nasadením skontrolujte text podmienok, URL zásad ochrany osobných údajov a právny základ spracúvania údajov.
- Nová analytika sa zbiera od verzie 0.4.0. Historické importy forms.app nemajú údaje o zobrazeniach, zariadeniach, OS ani priebehu vypĺňania.
- Zobrazenia sa zaznamenávajú pri načítaní testu; začatie až po prvej odpovedi. Drop-off preto ukazuje poslednú zodpovedanú otázku, nie iba otvorenú obrazovku.
- IP adresa sa zámerne neukladá. Automatická lehota mazania starých záznamov nie je implementovaná. Aktualizujte informácie o spracúvaní údajov vo svojich zásadách ochrany súkromia.

SHORTCODE
[digitalny_detox_test]
